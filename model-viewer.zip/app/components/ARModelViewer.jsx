"use client"

import { useState, useEffect } from "react"
import "../styles/ar-model-viewer.css"

export default function ARModelViewer({ modelUrl, onClose }) {
  const [error, setError] = useState(null)
  const [isValidating, setIsValidating] = useState(true)

  useEffect(() => {
    try {
      const urlObj = new URL(modelUrl)
      const validExtensions = [".glb", ".gltf"]
      const hasValidExtension = validExtensions.some((ext) => modelUrl.toLowerCase().includes(ext))

      if (!hasValidExtension) {
        setError("Invalid model format. Only GLB and GLTF models are supported.")
      }
    } catch (err) {
      setError("Invalid model URL. Please scan a valid QR code with a 3D model URL.")
    } finally {
      setIsValidating(false)
    }
  }, []) // Empty dependency - only run once

  useEffect(() => {
    if (!customElements.get("model-viewer")) {
      const script = document.createElement("script")
      script.type = "module"
      script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js"
      document.head.appendChild(script)
    }
  }, [])

  const handleModelError = (e) => {
    console.error("Model loading error:", e)
    setError("Failed to load the 3D model. The URL may be invalid or the model file may be corrupted.")
  }

  return (
    <div className="ar-model-viewer-overlay">
      <div className="ar-model-viewer-container">
        <div className="ar-viewer-header">
          <h2>AR Model Preview</h2>
          <button className="ar-close-button" onClick={onClose} aria-label="Close Viewer">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="ar-viewer-content">
          {isValidating ? (
            <div className="ar-loader">
              <div className="spinner"></div>
              <p>Validating model URL...</p>
            </div>
          ) : error ? (
            <div className="ar-error-state">
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <path d="M15 9l-6 6m0-6l6 6" />
              </svg>
              <p className="ar-error-message">{error}</p>
              <div className="ar-error-actions">
                <button className="ar-back-button" onClick={onClose}>
                  Back
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="ar-model-wrapper">
                <model-viewer
                  src={modelUrl}
                  ar
                  ar-modes="webxr scene-viewer quick-look"
                  camera-controls
                  auto-rotate
                  shadow-intensity="1"
                  style={{ width: "100%", height: "500px" }}
                  onError={handleModelError}
                ></model-viewer>
              </div>

              <div className="ar-instructions">
                <div className="ar-info-card">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                    <path d="M8 21h8M12 17v4" />
                  </svg>
                  <div>
                    <h3>View in AR</h3>
                    <p>Click the AR button in the viewer to place this model in your real environment</p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
