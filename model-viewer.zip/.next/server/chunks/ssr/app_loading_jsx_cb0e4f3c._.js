module.exports=[11797,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_loading_jsx_cb0e4f3c._.js.map