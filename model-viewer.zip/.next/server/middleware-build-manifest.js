globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cbd55ab9639e1e66.js",
    "static/chunks/99b78979f4b93ac1.js",
    "static/chunks/18a5a133fb68ca26.js",
    "static/chunks/5ef1a1aeafe8bfb5.js",
    "static/chunks/turbopack-7342d74910b1c070.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];