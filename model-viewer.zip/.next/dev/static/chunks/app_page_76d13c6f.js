(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_942f28d2._.js",
  "static/chunks/node_modules_html5-qrcode_esm_03101fc2._.js",
  "static/chunks/node_modules_html5-qrcode_third_party_zxing-js_umd_554f3425.js",
  "static/chunks/node_modules_next_7916ff3e._.js",
  "static/chunks/app_styles_5f6d84a6._.css"
],
    source: "dynamic"
});
