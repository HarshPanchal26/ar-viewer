(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/Header.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function Header(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(39);
    if ($[0] !== "041c0ce3cee5e2972b2e456b051f5c7a420f3c1caec1730b6f2c09c9fc7cf9fb") {
        for(let $i = 0; $i < 39; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "041c0ce3cee5e2972b2e456b051f5c7a420f3c1caec1730b6f2c09c9fc7cf9fb";
    }
    const { onQRScanClick, onSearch, searchQuery } = t0;
    const [localSearchQuery, setLocalSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(searchQuery || "");
    const [isSearchOpen, setIsSearchOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "Header[handleSearchChange]": (e)=>{
                setLocalSearchQuery(e.target.value);
            }
        })["Header[handleSearchChange]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const handleSearchChange = t1;
    let t2;
    if ($[2] !== localSearchQuery || $[3] !== onSearch) {
        t2 = ({
            "Header[handleSearchSubmit]": (e_0)=>{
                e_0.preventDefault();
                if (onSearch) {
                    onSearch(localSearchQuery);
                }
            }
        })["Header[handleSearchSubmit]"];
        $[2] = localSearchQuery;
        $[3] = onSearch;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const handleSearchSubmit = t2;
    let t3;
    if ($[5] !== onSearch) {
        t3 = ({
            "Header[handleClearSearch]": ()=>{
                setLocalSearchQuery("");
                if (onSearch) {
                    onSearch("");
                }
                setIsSearchOpen(false);
            }
        })["Header[handleClearSearch]"];
        $[5] = onSearch;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const handleClearSearch = t3;
    let t4;
    if ($[7] !== isSearchOpen) {
        t4 = ({
            "Header[toggleSearch]": ()=>{
                setIsSearchOpen(!isSearchOpen);
            }
        })["Header[toggleSearch]"];
        $[7] = isSearchOpen;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const toggleSearch = t4;
    let t5;
    let t6;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "logo-container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: "/Anubhav_logo_1.png",
                alt: "Anubhav Logo",
                className: "logo-img",
                style: {
                    height: "40px",
                    width: "auto"
                }
            }, void 0, false, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 83,
                columnNumber: 42
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 83,
            columnNumber: 10
        }, this);
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "header-divider"
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[9] = t5;
        $[10] = t6;
    } else {
        t5 = $[9];
        t6 = $[10];
    }
    let t7;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "header-title-section",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "header-title",
                    children: "AR Lab"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 96,
                    columnNumber: 48
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "header-subtitle",
                    children: "Augmented Reality Experience"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 96,
                    columnNumber: 88
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 96,
            columnNumber: 10
        }, this);
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== localSearchQuery) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Search models...",
            value: localSearchQuery,
            onChange: handleSearchChange,
            className: "search-input"
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 103,
            columnNumber: 10
        }, this);
        $[12] = localSearchQuery;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] !== handleClearSearch || $[15] !== localSearchQuery) {
        t9 = localSearchQuery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: handleClearSearch,
            className: "clear-search-btn",
            "aria-label": "Clear search",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: "18",
                height: "18",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: "18",
                        y1: "6",
                        x2: "6",
                        y2: "18"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 111,
                        columnNumber: 233
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: "6",
                        y1: "6",
                        x2: "18",
                        y2: "18"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 111,
                        columnNumber: 271
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 111,
                columnNumber: 135
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 111,
            columnNumber: 30
        }, this);
        $[14] = handleClearSearch;
        $[15] = localSearchQuery;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            className: "search-btn",
            "aria-label": "Search",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: "20",
                height: "20",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: "11",
                        cy: "11",
                        r: "8"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 120,
                        columnNumber: 174
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "m21 21-4.35-4.35"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 120,
                        columnNumber: 206
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 120,
                columnNumber: 76
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 120,
            columnNumber: 11
        }, this);
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== handleSearchSubmit || $[19] !== t8 || $[20] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            className: "search-form desktop-search",
            onSubmit: handleSearchSubmit,
            children: [
                t8,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 127,
            columnNumber: 11
        }, this);
        $[18] = handleSearchSubmit;
        $[19] = t8;
        $[20] = t9;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "22",
            height: "22",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "11",
                    cy: "11",
                    r: "8"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 137,
                    columnNumber: 109
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "m21 21-4.35-4.35"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 137,
                    columnNumber: 141
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 137,
            columnNumber: 11
        }, this);
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] !== toggleSearch) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "icon-btn mobile-search-toggle",
            onClick: toggleSearch,
            "aria-label": "Toggle search",
            children: t12
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 144,
            columnNumber: 11
        }, this);
        $[23] = toggleSearch;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    let t14;
    if ($[25] !== onQRScanClick) {
        t14 = onQRScanClick && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "icon-btn qr-scan-button",
            onClick: onQRScanClick,
            "aria-label": "Scan QR Code",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "22",
                    height: "22",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "3",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 152,
                            columnNumber: 220
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "14",
                            y: "3",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 152,
                            columnNumber: 261
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "14",
                            y: "14",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 152,
                            columnNumber: 303
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "14",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 152,
                            columnNumber: 346
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 152,
                    columnNumber: 122
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "btn-text",
                    children: "Scan QR"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 152,
                    columnNumber: 394
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 152,
            columnNumber: 28
        }, this);
        $[25] = onQRScanClick;
        $[26] = t14;
    } else {
        t14 = $[26];
    }
    let t15;
    if ($[27] !== t11 || $[28] !== t13 || $[29] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "header-content",
            children: [
                t5,
                t6,
                t7,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "header-actions",
                    children: [
                        t11,
                        t13,
                        t14
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 160,
                    columnNumber: 55
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[27] = t11;
        $[28] = t13;
        $[29] = t14;
        $[30] = t15;
    } else {
        t15 = $[30];
    }
    let t16;
    if ($[31] !== handleClearSearch || $[32] !== handleSearchSubmit || $[33] !== isSearchOpen || $[34] !== localSearchQuery) {
        t16 = isSearchOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mobile-search-dropdown",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                className: "search-form",
                onSubmit: handleSearchSubmit,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        placeholder: "Search models...",
                        value: localSearchQuery,
                        onChange: handleSearchChange,
                        className: "search-input",
                        autoFocus: true
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 170,
                        columnNumber: 127
                    }, this),
                    localSearchQuery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleClearSearch,
                        className: "clear-search-btn",
                        "aria-label": "Clear search",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "18",
                            height: "18",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                    x1: "18",
                                    y1: "6",
                                    x2: "6",
                                    y2: "18"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 170,
                                    columnNumber: 500
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                    x1: "6",
                                    y1: "6",
                                    x2: "18",
                                    y2: "18"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 170,
                                    columnNumber: 538
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 170,
                            columnNumber: 402
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 170,
                        columnNumber: 297
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "search-btn",
                        "aria-label": "Search",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "20",
                            height: "20",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                    cx: "11",
                                    cy: "11",
                                    r: "8"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 170,
                                    columnNumber: 755
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "m21 21-4.35-4.35"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 170,
                                    columnNumber: 787
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 170,
                            columnNumber: 657
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 170,
                        columnNumber: 592
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 170,
                columnNumber: 67
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 170,
            columnNumber: 27
        }, this);
        $[31] = handleClearSearch;
        $[32] = handleSearchSubmit;
        $[33] = isSearchOpen;
        $[34] = localSearchQuery;
        $[35] = t16;
    } else {
        t16 = $[35];
    }
    let t17;
    if ($[36] !== t15 || $[37] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: "header",
            children: [
                t15,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 181,
            columnNumber: 11
        }, this);
        $[36] = t15;
        $[37] = t16;
        $[38] = t17;
    } else {
        t17 = $[38];
    }
    return t17;
}
_s(Header, "hQa3r9ax3LCilIwlmfoq+4Tm6UY=");
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ModelList.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client"
// import "../styles/model-list.css"
// export default function ModelList({
//   models,
//   onSelectModel,
//   currentPage,
//   totalPages,
//   onPageChange,
//   loading,
//   searchQuery,
// }) {
//   return (
//     <div className="model-list-container">
//       <div className="model-list-header">
//         <div className="header-left">
//           <h2>Discover AR Models</h2>
//           <p className="model-count">
//             {searchQuery && `Search results for "${searchQuery}" - `}
//             {models.length} model{models.length !== 1 ? "s" : ""}
//           </p>
//         </div>
//       </div>
//       <div className="model-grid">
//         {models.map((model, index) => (
//           <div key={index} className="model-card" onClick={() => onSelectModel(model)}>
//             <div className="model-card-image">
//               <img
//                 src={
//                   model.posterImage ||
//                   "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" ||
//                   "/placeholder.svg" ||
//                   "/placeholder.svg"
//                 }
//                 alt={model.modelName}
//                 loading="lazy"
//               />
//               {(model.hasAR || model.hasAudio) && (
//                 <div className="card-badges">
//                   {model.hasAR && (
//                     <span className="card-badge">
//                       <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                         <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
//                         <path d="M8 21h8M12 17v4" />
//                       </svg>
//                       AR
//                     </span>
//                   )}
//                   {model.hasAudio && (
//                     <span className="card-badge">
//                       <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                         <path d="M11 5L6 9H2v6h4l5 4V5z" />
//                         <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
//                       </svg>
//                       Audio
//                     </span>
//                   )}
//                 </div>
//               )}
//               <div className="model-card-overlay">
//                 <span className="view-model-text">View Model</span>
//               </div>
//             </div>
//             <div className="model-card-content">
//               <h3 className="model-card-title">{model.modelName}</h3>
//             </div>
//           </div>
//         ))}
//       </div>
//       {totalPages > 1 && (
//         <div className="pagination-container">
//           <button
//             className="pagination-btn"
//             onClick={() => onPageChange(currentPage - 1)}
//             disabled={currentPage === 1 || loading}
//           >
//             Previous
//           </button>
//           <div className="pagination-numbers">
//             {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
//               <button
//                 key={page}
//                 className={`pagination-number ${page === currentPage ? "active" : ""}`}
//                 onClick={() => onPageChange(page)}
//                 disabled={loading}
//               >
//                 {page}
//               </button>
//             ))}
//           </div>
//           <button
//             className="pagination-btn"
//             onClick={() => onPageChange(currentPage + 1)}
//             disabled={currentPage === totalPages || loading}
//           >
//             Next
//           </button>
//         </div>
//       )}
//     </div>
//   )
// }
// "use client"
// import "../styles/model-list.css"
// export default function ModelList({
//   models,
//   onSelectModel,
//   currentPage,
//   totalCount,
//   onPageChange,
//   loading,
//   searchQuery,
// }) {
//   const itemsPerPage = 10
//   const totalPages = Math.ceil(totalCount / itemsPerPage)
//   return (
//     <div className="model-list-container">
//       <div className="model-list-header">
//         <div className="header-left">
//           <h2>Discover AR Models</h2>
//           <p className="model-count">
//             {searchQuery && `Search results for "${searchQuery}" - `}
//             {models.length} model{models.length !== 1 ? "s" : ""} {!searchQuery && totalCount > 0 && `of ${totalCount}`}
//           </p>
//         </div>
//       </div>
//       <div className="model-grid">
//         {models.map((model, index) => (
//           <div key={model.modelId || index} className="model-card" onClick={() => onSelectModel(model)}>
//             <div className="model-card-image">
//               <img
//                 src={
//                   model.posterImage ||
//                   "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" ||
//                   "/placeholder.svg"
//                 }
//                 alt={model.modelName}
//                 loading="lazy"
//               />
//               {(model.hasAR || model.hasAudio) && (
//                 <div className="card-badges">
//                   {model.hasAR && (
//                     <span className="card-badge">
//                       <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                         <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
//                         <path d="M8 21h8M12 17v4" />
//                       </svg>
//                       AR
//                     </span>
//                   )}
//                   {model.hasAudio && (
//                     <span className="card-badge">
//                       <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                         <path d="M11 5L6 9H2v6h4l5 4V5z" />
//                         <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
//                       </svg>
//                       Audio
//                     </span>
//                   )}
//                 </div>
//               )}
//               <div className="model-card-overlay">
//                 <span className="view-model-text">View Model</span>
//               </div>
//             </div>
//             <div className="model-card-content">
//               <h3 className="model-card-title">{model.modelName}</h3>
//               {model.subjectName && model.className && (
//                 <p className="model-card-meta">
//                   {model.subjectName} • {model.className}
//                 </p>
//               )}
//             </div>
//           </div>
//         ))}
//       </div>
//       {totalPages > 1 && !searchQuery && (
//         <div className="pagination-container">
//           <button
//             className="pagination-btn"
//             onClick={() => onPageChange(currentPage - 1)}
//             disabled={currentPage === 1 || loading}
//           >
//             Previous
//           </button>
//           <div className="pagination-numbers">
//             {(() => {
//               const maxVisible = 7
//               let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2))
//               const endPage = Math.min(totalPages, startPage + maxVisible - 1)
//               if (endPage - startPage + 1 < maxVisible) {
//                 startPage = Math.max(1, endPage - maxVisible + 1)
//               }
//               const pages = []
//               for (let i = startPage; i <= endPage; i++) {
//                 pages.push(i)
//               }
//               return pages.map((page) => (
//                 <button
//                   key={page}
//                   className={`pagination-number ${page === currentPage ? "active" : ""}`}
//                   onClick={() => onPageChange(page)}
//                   disabled={loading}
//                 >
//                   {page}
//                 </button>
//               ))
//             })()}
//           </div>
//           <button
//             className="pagination-btn"
//             onClick={() => onPageChange(currentPage + 1)}
//             disabled={currentPage === totalPages || loading}
//           >
//             Next
//           </button>
//         </div>
//       )}
//     </div>
//   )
// }
__turbopack_context__.s([
    "default",
    ()=>ModelList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
function ModelList(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    if ($[0] !== "a85c30ab26ae2a4239be0f68be78d127360f458d17999e44430c2dc298ad8757") {
        for(let $i = 0; $i < 25; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a85c30ab26ae2a4239be0f68be78d127360f458d17999e44430c2dc298ad8757";
    }
    const { models, onSelectModel, currentPage: t1, totalCount: t2, onPageChange, loading, searchQuery, sectionTitle: t3, showPagination: t4 } = t0;
    const currentPage = t1 === undefined ? 1 : t1;
    const totalCount = t2 === undefined ? 0 : t2;
    const sectionTitle = t3 === undefined ? "Discover AR Models" : t3;
    const showPagination = t4 === undefined ? true : t4;
    const totalPages = Math.ceil(totalCount / 10);
    let t5;
    if ($[1] !== sectionTitle) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            children: sectionTitle
        }, void 0, false, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 267,
            columnNumber: 10
        }, this);
        $[1] = sectionTitle;
        $[2] = t5;
    } else {
        t5 = $[2];
    }
    const t6 = searchQuery && `Search results for "${searchQuery}" - `;
    let t7;
    if ($[3] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "model-count",
            children: t6
        }, void 0, false, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 276,
            columnNumber: 10
        }, this);
        $[3] = t6;
        $[4] = t7;
    } else {
        t7 = $[4];
    }
    let t8;
    if ($[5] !== t5 || $[6] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-list-header",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "header-left",
                children: [
                    t5,
                    t7
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ModelList.jsx",
                lineNumber: 284,
                columnNumber: 45
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 284,
            columnNumber: 10
        }, this);
        $[5] = t5;
        $[6] = t7;
        $[7] = t8;
    } else {
        t8 = $[7];
    }
    let t9;
    if ($[8] !== models || $[9] !== onSelectModel) {
        let t10;
        if ($[11] !== onSelectModel) {
            t10 = ({
                "ModelList[models.map()]": (model, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "model-card",
                        onClick: {
                            "ModelList[models.map() > <div>.onClick]": ()=>onSelectModel(model)
                        }["ModelList[models.map() > <div>.onClick]"],
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "model-card-image",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: model.posterImage || "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" || "/placeholder.svg" || "/placeholder.svg",
                                        alt: model.modelName,
                                        loading: "lazy"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 298,
                                        columnNumber: 89
                                    }, this),
                                    (model.hasAR || model.hasAudio) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "card-badges",
                                        children: [
                                            model.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "card-badge",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        width: "12",
                                                        height: "12",
                                                        viewBox: "0 0 24 24",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        strokeWidth: "2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                                x: "2",
                                                                y: "3",
                                                                width: "20",
                                                                height: "14",
                                                                rx: "2",
                                                                ry: "2"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 298,
                                                                columnNumber: 499
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M8 21h8M12 17v4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 298,
                                                                columnNumber: 556
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/components/ModelList.jsx",
                                                        lineNumber: 298,
                                                        columnNumber: 401
                                                    }, this),
                                                    "AR"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/ModelList.jsx",
                                                lineNumber: 298,
                                                columnNumber: 372
                                            }, this),
                                            model.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "card-badge",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        width: "12",
                                                        height: "12",
                                                        viewBox: "0 0 24 24",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        strokeWidth: "2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M11 5L6 9H2v6h4l5 4V5z"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 298,
                                                                columnNumber: 746
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 298,
                                                                columnNumber: 781
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/components/ModelList.jsx",
                                                        lineNumber: 298,
                                                        columnNumber: 648
                                                    }, this),
                                                    "Audio"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/ModelList.jsx",
                                                lineNumber: 298,
                                                columnNumber: 619
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 298,
                                        columnNumber: 327
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "model-card-overlay",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "view-model-text",
                                            children: "View Model"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ModelList.jsx",
                                            lineNumber: 298,
                                            columnNumber: 915
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 298,
                                        columnNumber: 879
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ModelList.jsx",
                                lineNumber: 298,
                                columnNumber: 55
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "model-card-content",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "model-card-title",
                                        children: model.modelName
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 298,
                                        columnNumber: 1014
                                    }, this),
                                    model.subjectName && model.className && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "model-card-meta",
                                        children: [
                                            model.subjectName,
                                            " • ",
                                            model.className
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 298,
                                        columnNumber: 1110
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ModelList.jsx",
                                lineNumber: 298,
                                columnNumber: 978
                            }, this)
                        ]
                    }, model.modelId || index, true, {
                        fileName: "[project]/app/components/ModelList.jsx",
                        lineNumber: 296,
                        columnNumber: 54
                    }, this)
            })["ModelList[models.map()]"];
            $[11] = onSelectModel;
            $[12] = t10;
        } else {
            t10 = $[12];
        }
        t9 = models.map(t10);
        $[8] = models;
        $[9] = onSelectModel;
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[13] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-grid",
            children: t9
        }, void 0, false, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 314,
            columnNumber: 11
        }, this);
        $[13] = t9;
        $[14] = t10;
    } else {
        t10 = $[14];
    }
    let t11;
    if ($[15] !== currentPage || $[16] !== loading || $[17] !== onPageChange || $[18] !== showPagination || $[19] !== totalPages) {
        t11 = showPagination && totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pagination-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "pagination-btn",
                    onClick: {
                        "ModelList[<button>.onClick]": ()=>onPageChange(currentPage - 1)
                    }["ModelList[<button>.onClick]"],
                    disabled: currentPage === 1 || loading,
                    children: "Previous"
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelList.jsx",
                    lineNumber: 322,
                    columnNumber: 85
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pagination-numbers",
                    children: (()=>{
                        let startPage = Math.max(1, currentPage - Math.floor(3.5));
                        const endPage = Math.min(totalPages, startPage + 7 - 1);
                        if (endPage - startPage + 1 < 7) {
                            startPage = Math.max(1, endPage - 7 + 1);
                        }
                        const pages = [];
                        for(let i = startPage; i <= endPage; i++){
                            pages.push(i);
                        }
                        return pages.map({
                            "ModelList[<anonymous> > pages.map()]": (page)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `pagination-number ${page === currentPage ? "active" : ""}`,
                                    onClick: {
                                        "ModelList[<anonymous> > pages.map() > <button>.onClick]": ()=>onPageChange(page)
                                    }["ModelList[<anonymous> > pages.map() > <button>.onClick]"],
                                    disabled: loading,
                                    children: page
                                }, page, false, {
                                    fileName: "[project]/app/components/ModelList.jsx",
                                    lineNumber: 335,
                                    columnNumber: 61
                                }, this)
                        }["ModelList[<anonymous> > pages.map()]"]);
                    })()
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelList.jsx",
                    lineNumber: 324,
                    columnNumber: 98
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "pagination-btn",
                    onClick: {
                        "ModelList[<button>.onClick]": ()=>onPageChange(currentPage + 1)
                    }["ModelList[<button>.onClick]"],
                    disabled: currentPage === totalPages || loading,
                    children: "Next"
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelList.jsx",
                    lineNumber: 339,
                    columnNumber: 20
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 322,
            columnNumber: 47
        }, this);
        $[15] = currentPage;
        $[16] = loading;
        $[17] = onPageChange;
        $[18] = showPagination;
        $[19] = totalPages;
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    let t12;
    if ($[21] !== t10 || $[22] !== t11 || $[23] !== t8) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-list-container",
            children: [
                t8,
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 353,
            columnNumber: 11
        }, this);
        $[21] = t10;
        $[22] = t11;
        $[23] = t8;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    return t12;
}
_c = ModelList;
var _c;
__turbopack_context__.k.register(_c, "ModelList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ModelViewerComponent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// // "use client"
// // import { useEffect } from "react"
// // export default function ModelViewerComponent({ posterImage, modelUrl, modelName }) {
// //   useEffect(() => {
// //     // Dynamically load model-viewer script if not already loaded
// //     if (!window.customElements.get("model-viewer")) {
// //       const script = document.createElement("script")
// //       script.type = "module"
// //       script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.3.0/model-viewer.min.js"
// //       document.head.appendChild(script)
// //     }
// //   }, [])
// //   return (
// //     <model-viewer
// //       poster={posterImage}
// //       src={modelUrl}
// //       alt={modelName}
// //       ar
// //       ar-modes="webxr scene-viewer quick-look"
// //       camera-controls
// //       autoplay
// //       enable-pan
// //       style={{
// //         width: "100%",
// //         height: "100%",
// //         display: "block",
// //         background: "#1c1c1c",
// //       }}
// //     />
// //   )
// // }
// "use client"
// import { useEffect, useRef, useState } from "react"
// export default function ModelViewerComponent({ posterImage, modelUrl, modelName, audioUrl, iosModelUrl }) {
//   const modelViewerRef = useRef(null)
//   const audioRef = useRef(null)
//   const [isARActive, setIsARActive] = useState(false)
//   const [arSupported, setArSupported] = useState(false)
//   useEffect(() => {
//     // Dynamically load model-viewer script if not already loaded
//     if (!window.customElements.get("model-viewer")) {
//       const script = document.createElement("script")
//       script.type = "module"
//       script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.3.0/model-viewer.min.js"
//       document.head.appendChild(script)
//     }
//     if (modelViewerRef.current) {
//       const checkARSupport = async () => {
//         if (navigator.xr) {
//           const supported = await navigator.xr.isSessionSupported("immersive-ar")
//           setArSupported(supported)
//         } else if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
//           // iOS devices support AR Quick Look
//           setArSupported(true)
//         } else if (/Android/.test(navigator.userAgent)) {
//           // Android devices support Scene Viewer
//           setArSupported(true)
//         }
//       }
//       checkARSupport()
//     }
//   }, [])
//   useEffect(() => {
//     const modelViewer = modelViewerRef.current
//     if (!modelViewer) return
//     const handleARStatus = (event) => {
//       console.log("[v0] AR Status:", event.type)
//       if (event.type === "ar-status") {
//         setIsARActive(event.detail.status === "session-started")
//       }
//     }
//     const handleQuickLookButtonTapped = () => {
//       console.log("[v0] Quick Look AR activated")
//       setIsARActive(true)
//       if (audioRef.current && audioUrl) {
//         audioRef.current.play().catch((err) => console.error("[v0] Audio play failed:", err))
//       }
//     }
//     modelViewer.addEventListener("ar-status", handleARStatus)
//     modelViewer.addEventListener("quick-look-button-tapped", handleQuickLookButtonTapped)
//     return () => {
//       modelViewer.removeEventListener("ar-status", handleARStatus)
//       modelViewer.removeEventListener("quick-look-button-tapped", handleQuickLookButtonTapped)
//     }
//   }, [audioUrl])
//   useEffect(() => {
//     if (isARActive && audioRef.current && audioUrl) {
//       console.log("[v0] Playing audio in AR mode")
//       audioRef.current.play().catch((err) => console.error("[v0] Audio play failed:", err))
//     } else if (!isARActive && audioRef.current) {
//       audioRef.current.pause()
//       audioRef.current.currentTime = 0
//     }
//   }, [isARActive, audioUrl])
//   return (
//     <>
//       <model-viewer
//         ref={modelViewerRef}
//         poster={posterImage}
//         src={modelUrl}
//         ios-src={iosModelUrl || modelUrl}
//         alt={modelName}
//         ar
//         ar-modes="webxr scene-viewer quick-look"
//         camera-controls
//         autoplay
//         enable-pan
//         shadow-intensity="1"
//         environment-image="neutral"
//         exposure="1"
//         style={{
//           width: "100%",
//           height: "100%",
//           display: "block",
//           background: "#1c1c1c",
//         }}
//       />
//       {audioUrl && <audio ref={audioRef} src={audioUrl} loop preload="auto" style={{ display: "none" }} />}
//       {arSupported && (
//         <div
//           style={{
//             position: "absolute",
//             bottom: "20px",
//             left: "50%",
//             transform: "translateX(-50%)",
//             background: "rgba(0, 0, 0, 0.7)",
//             color: "white",
//             padding: "8px 16px",
//             borderRadius: "20px",
//             fontSize: "14px",
//             display: "flex",
//             alignItems: "center",
//             gap: "8px",
//             zIndex: 10,
//           }}
//         >
//           <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//             <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
//             <path d="M8 21h8M12 17v4" />
//           </svg>
//           AR Available - Tap the AR button
//         </div>
//       )}
//     </>
//   )
// }
__turbopack_context__.s([
    "default",
    ()=>ModelViewerComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ModelViewerComponent(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24);
    if ($[0] !== "b1885daa39f9f2ef1d60369883e5679d71524651ebe081c247a3ddf841779c7b") {
        for(let $i = 0; $i < 24; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b1885daa39f9f2ef1d60369883e5679d71524651ebe081c247a3ddf841779c7b";
    }
    const { posterImage, modelUrl, modelName, audioUrl, iosModelUrl, dracoUrl } = t0;
    const modelViewerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const audioRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isARActive, setIsARActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [arSupported, setArSupported] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ModelViewerComponent[useEffect()]": ()=>{
                if (!window.customElements.get("model-viewer")) {
                    const script = document.createElement("script");
                    script.type = "module";
                    script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.3.0/model-viewer.min.js";
                    document.head.appendChild(script);
                }
                if (modelViewerRef.current) {
                    const checkARSupport = {
                        "ModelViewerComponent[useEffect() > checkARSupport]": async ()=>{
                            if (navigator.xr) {
                                const supported = await navigator.xr.isSessionSupported("immersive-ar");
                                setArSupported(supported);
                            } else {
                                if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
                                    setArSupported(true);
                                } else {
                                    if (/Android/.test(navigator.userAgent)) {
                                        setArSupported(true);
                                    }
                                }
                            }
                        }
                    }["ModelViewerComponent[useEffect() > checkARSupport]"];
                    checkARSupport();
                }
            }
        })["ModelViewerComponent[useEffect()]"];
        t2 = [];
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    let t4;
    if ($[3] !== audioUrl) {
        t3 = ({
            "ModelViewerComponent[useEffect()]": ()=>{
                const modelViewer = modelViewerRef.current;
                if (!modelViewer) {
                    return;
                }
                const handleARStatus = {
                    "ModelViewerComponent[useEffect() > handleARStatus]": (event)=>{
                        if (event.type === "ar-status") {
                            setIsARActive(event.detail.status === "session-started");
                        }
                    }
                }["ModelViewerComponent[useEffect() > handleARStatus]"];
                const handleQuickLookButtonTapped = {
                    "ModelViewerComponent[useEffect() > handleQuickLookButtonTapped]": ()=>{
                        setIsARActive(true);
                        if (audioRef.current && audioUrl) {
                            audioRef.current.play().catch(_ModelViewerComponentUseEffectHandleQuickLookButtonTappedAnonymous);
                        }
                    }
                }["ModelViewerComponent[useEffect() > handleQuickLookButtonTapped]"];
                modelViewer.addEventListener("ar-status", handleARStatus);
                modelViewer.addEventListener("quick-look-button-tapped", handleQuickLookButtonTapped);
                return ()=>{
                    modelViewer.removeEventListener("ar-status", handleARStatus);
                    modelViewer.removeEventListener("quick-look-button-tapped", handleQuickLookButtonTapped);
                };
            }
        })["ModelViewerComponent[useEffect()]"];
        t4 = [
            audioUrl
        ];
        $[3] = audioUrl;
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    let t6;
    if ($[6] !== audioUrl || $[7] !== isARActive) {
        t5 = ({
            "ModelViewerComponent[useEffect()]": ()=>{
                if (isARActive && audioRef.current && audioUrl) {
                    audioRef.current.play().catch(_ModelViewerComponentUseEffectAnonymous);
                } else {
                    if (!isARActive && audioRef.current) {
                        audioRef.current.pause();
                        audioRef.current.currentTime = 0;
                    }
                }
            }
        })["ModelViewerComponent[useEffect()]"];
        t6 = [
            isARActive,
            audioUrl
        ];
        $[6] = audioUrl;
        $[7] = isARActive;
        $[8] = t5;
        $[9] = t6;
    } else {
        t5 = $[8];
        t6 = $[9];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    const finalModelUrl = dracoUrl || modelUrl;
    const t7 = iosModelUrl || finalModelUrl;
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            width: "100%",
            height: "100%",
            display: "block",
            background: "#1c1c1c"
        };
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== finalModelUrl || $[12] !== modelName || $[13] !== posterImage || $[14] !== t7) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("model-viewer", {
            ref: modelViewerRef,
            poster: posterImage,
            src: finalModelUrl,
            "ios-src": t7,
            alt: modelName,
            ar: true,
            "ar-modes": "webxr scene-viewer quick-look",
            "camera-controls": true,
            autoplay: true,
            "enable-pan": true,
            "shadow-intensity": "1",
            "environment-image": "neutral",
            exposure: "1",
            style: t8
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewerComponent.jsx",
            lineNumber: 310,
            columnNumber: 10
        }, this);
        $[11] = finalModelUrl;
        $[12] = modelName;
        $[13] = posterImage;
        $[14] = t7;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] !== audioUrl) {
        t10 = audioUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("audio", {
            ref: audioRef,
            src: audioUrl,
            loop: true,
            preload: "auto",
            style: {
                display: "none"
            }
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewerComponent.jsx",
            lineNumber: 321,
            columnNumber: 23
        }, this);
        $[16] = audioUrl;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== arSupported) {
        t11 = arSupported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                position: "absolute",
                bottom: "20px",
                left: "50%",
                transform: "translateX(-50%)",
                background: "rgba(0, 0, 0, 0.7)",
                color: "white",
                padding: "8px 16px",
                borderRadius: "20px",
                fontSize: "14px",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                zIndex: 10
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "16",
                    height: "16",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "2",
                            y: "3",
                            width: "20",
                            height: "14",
                            rx: "2",
                            ry: "2"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewerComponent.jsx",
                            lineNumber: 345,
                            columnNumber: 106
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M8 21h8M12 17v4"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewerComponent.jsx",
                            lineNumber: 345,
                            columnNumber: 163
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ModelViewerComponent.jsx",
                    lineNumber: 345,
                    columnNumber: 8
                }, this),
                "AR Available - Tap the AR button"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewerComponent.jsx",
            lineNumber: 331,
            columnNumber: 26
        }, this);
        $[18] = arSupported;
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    let t12;
    if ($[20] !== t10 || $[21] !== t11 || $[22] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t9,
                t10,
                t11
            ]
        }, void 0, true);
        $[20] = t10;
        $[21] = t11;
        $[22] = t9;
        $[23] = t12;
    } else {
        t12 = $[23];
    }
    return t12;
}
_s(ModelViewerComponent, "OZJwjXJCCswTIhy96RD5irULZQk=");
_c = ModelViewerComponent;
function _ModelViewerComponentUseEffectAnonymous(err_0) {
    return console.error("Audio play failed:", err_0);
}
function _ModelViewerComponentUseEffectHandleQuickLookButtonTappedAnonymous(err) {
    return console.error("Audio play failed:", err);
}
var _c;
__turbopack_context__.k.register(_c, "ModelViewerComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ModelViewer.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// // "use client"
// // import { useState, useEffect } from "react"
// // import ModelViewerComponent from "./ModelViewerComponent"
// // import "../styles/model-viewer.css"
// // export default function ModelViewer({ model, onBack, allModels, onSelectModel }) {
// //   const [loading, setLoading] = useState(true)
// //   useEffect(() => {
// //     setLoading(true)
// //     const timer = setTimeout(() => setLoading(false), 1000)
// //     return () => clearTimeout(timer)
// //   }, [model])
// //   const modelUrl = model.dracoURL || model.URL
// //   return (
// //     <div className="model-viewer-container">
// //       <div className="viewer-header">
// //         <button className="back-button" onClick={onBack}>
// //           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
// //             <path d="M19 12H5M12 19l-7-7 7-7" />
// //           </svg>
// //           Go Back
// //         </button>
// //       </div>
// //       <div className="viewer-content">
// //         <div className="viewer-main">
// //           <div className="model-viewer-wrapper">
// //             {loading && (
// //               <div className="viewer-loader">
// //                 <div className="spinner"></div>
// //                 <p>Loading 3D Model...</p>
// //               </div>
// //             )}
// //             <ModelViewerComponent posterImage={model.posterImage} modelUrl={modelUrl} modelName={model.modelName} />
// //           </div>
// //           <div className="model-info">
// //             <h2 className="model-title">{model.modelName}</h2>
// //           </div>
// //         </div>
// //         <div className="viewer-sidebar">
// //           <h3 className="sidebar-title">3D Models</h3>
// //           <div className="model-list-sidebar">
// //             {allModels.map((m, index) => (
// //               <div
// //                 key={index}
// //                 className={`sidebar-model-item ${m.modelName === model.modelName ? "active" : ""}`}
// //                 onClick={() => onSelectModel(m)}
// //               >
// //                 <div className="sidebar-model-image">
// //                   <img
// //                     src={
// //                       m.posterImage ||
// //                       "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" ||
// //                       "/placeholder.svg"
// //                     }
// //                     alt={m.modelName}
// //                   />
// //                 </div>
// //                 <div className="sidebar-model-name">
// //                   <p>{m.modelName}</p>
// //                 </div>
// //               </div>
// //             ))}
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   )
// // }
// "use client"
// import { useState, useEffect } from "react"
// import ModelViewerComponent from "./ModelViewerComponent"
// import "../styles/model-viewer.css"
// export default function ModelViewer({ model, onBack, allModels, onSelectModel }) {
//   const [loading, setLoading] = useState(true)
//   useEffect(() => {
//     setLoading(true)
//     const timer = setTimeout(() => setLoading(false), 1000)
//     return () => clearTimeout(timer)
//   }, [model])
//   const modelUrl = model.dracoURL || model.URL
//   return (
//     <div className="model-viewer-container">
//       <div className="viewer-header">
//         <button className="back-button" onClick={onBack}>
//           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//             <path d="M19 12H5M12 19l-7-7 7-7" />
//           </svg>
//           Go Back
//         </button>
//         <div className="model-badges">
//           {model.hasAR && (
//             <span className="badge ar-badge">
//               <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
//                 <path d="M8 21h8M12 17v4" />
//               </svg>
//               AR Enabled
//             </span>
//           )}
//           {model.hasAudio && (
//             <span className="badge audio-badge">
//               <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <path d="M11 5L6 9H2v6h4l5 4V5z" />
//                 <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
//               </svg>
//               Audio
//             </span>
//           )}
//         </div>
//       </div>
//       <div className="viewer-content">
//         <div className="viewer-main">
//           <div className="model-viewer-wrapper">
//             {loading && (
//               <div className="viewer-loader">
//                 <div className="spinner"></div>
//                 <p>Loading 3D Model...</p>
//               </div>
//             )}
//             <ModelViewerComponent
//               posterImage={model.posterImage}
//               modelUrl={modelUrl}
//               modelName={model.modelName}
//               audioUrl={model.audioUrl}
//               iosModelUrl={model.iosModelUrl}
//             />
//           </div>
//           <div className="model-info">
//             <h2 className="model-title">{model.modelName}</h2>
//             {model.hasAR && (
//               <p className="model-description">
//                 Click the AR icon in the viewer to experience this model in your real environment. Audio will play
//                 automatically in AR mode.
//               </p>
//             )}
//           </div>
//         </div>
//         <div className="viewer-sidebar">
//           <h3 className="sidebar-title">3D Models</h3>
//           <div className="model-list-sidebar">
//             {allModels.map((m, index) => (
//               <div
//                 key={index}
//                 className={`sidebar-model-item ${m.modelName === model.modelName ? "active" : ""}`}
//                 onClick={() => onSelectModel(m)}
//               >
//                 <div className="sidebar-model-image">
//                   <img
//                     src={
//                       m.posterImage ||
//                       "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" ||
//                       "/placeholder.svg" ||
//                       "/placeholder.svg"
//                     }
//                     alt={m.modelName}
//                   />
//                   {(m.hasAR || m.hasAudio) && (
//                     <div className="sidebar-badges">
//                       {m.hasAR && <span className="mini-badge">AR</span>}
//                       {m.hasAudio && <span className="mini-badge">🔊</span>}
//                     </div>
//                   )}
//                 </div>
//                 <div className="sidebar-model-name">
//                   <p>{m.modelName}</p>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }
__turbopack_context__.s([
    "default",
    ()=>ModelViewer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ModelViewerComponent.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ModelViewer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(61);
    if ($[0] !== "98c26fd6ad040f98a257a327276dff8aabbe4351dfe843b772632ca697085879") {
        for(let $i = 0; $i < 61; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "98c26fd6ad040f98a257a327276dff8aabbe4351dfe843b772632ca697085879";
    }
    const { model, onBack, allModels, onSelectModel } = t0;
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ModelViewer[useEffect()]": ()=>{
                setLoading(true);
                const timer = setTimeout({
                    "ModelViewer[useEffect() > setTimeout()]": ()=>setLoading(false)
                }["ModelViewer[useEffect() > setTimeout()]"], 1000);
                return ()=>clearTimeout(timer);
            }
        })["ModelViewer[useEffect()]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== model) {
        t2 = [
            model
        ];
        $[2] = model;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    model.dracoURL || model.URL;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "20",
            height: "20",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19 12H5M12 19l-7-7 7-7"
            }, void 0, false, {
                fileName: "[project]/app/components/ModelViewer.jsx",
                lineNumber: 238,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 238,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== onBack) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "back-button",
            onClick: onBack,
            children: [
                t3,
                "Go Back"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 245,
            columnNumber: 10
        }, this);
        $[5] = onBack;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== model.hasAR) {
        t5 = model.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "badge ar-badge",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "16",
                    height: "16",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "2",
                            y: "3",
                            width: "20",
                            height: "14",
                            rx: "2",
                            ry: "2"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 253,
                            columnNumber: 156
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M8 21h8M12 17v4"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 253,
                            columnNumber: 213
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 253,
                    columnNumber: 58
                }, this),
                "AR Enabled"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 253,
            columnNumber: 25
        }, this);
        $[7] = model.hasAR;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== model.hasAudio) {
        t6 = model.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "badge audio-badge",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "16",
                    height: "16",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M11 5L6 9H2v6h4l5 4V5z"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 261,
                            columnNumber: 162
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 261,
                            columnNumber: 197
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 261,
                    columnNumber: 64
                }, this),
                "Audio"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 261,
            columnNumber: 28
        }, this);
        $[9] = model.hasAudio;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== t5 || $[12] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-badges",
            children: [
                t5,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 269,
            columnNumber: 10
        }, this);
        $[11] = t5;
        $[12] = t6;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== t4 || $[15] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-header",
            children: [
                t4,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 278,
            columnNumber: 10
        }, this);
        $[14] = t4;
        $[15] = t7;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    let t9;
    if ($[17] !== loading) {
        t9 = loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-loader",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "spinner"
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 287,
                    columnNumber: 52
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Loading 3D Model..."
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 287,
                    columnNumber: 79
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 287,
            columnNumber: 21
        }, this);
        $[17] = loading;
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    let t10;
    if ($[19] !== model.URL || $[20] !== model.audioLink || $[21] !== model.dracoURL || $[22] !== model.iosModelUrl || $[23] !== model.modelName || $[24] !== model.posterImage) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            posterImage: model.posterImage,
            modelUrl: model.URL,
            modelName: model.modelName,
            audioUrl: model.audioLink,
            iosModelUrl: model.iosModelUrl,
            dracoUrl: model.dracoURL
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 295,
            columnNumber: 11
        }, this);
        $[19] = model.URL;
        $[20] = model.audioLink;
        $[21] = model.dracoURL;
        $[22] = model.iosModelUrl;
        $[23] = model.modelName;
        $[24] = model.posterImage;
        $[25] = t10;
    } else {
        t10 = $[25];
    }
    let t11;
    if ($[26] !== t10 || $[27] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-viewer-wrapper",
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 308,
            columnNumber: 11
        }, this);
        $[26] = t10;
        $[27] = t9;
        $[28] = t11;
    } else {
        t11 = $[28];
    }
    let t12;
    if ($[29] !== model.modelName) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "model-title",
            children: model.modelName
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 317,
            columnNumber: 11
        }, this);
        $[29] = model.modelName;
        $[30] = t12;
    } else {
        t12 = $[30];
    }
    let t13;
    if ($[31] !== model.chapterName || $[32] !== model.className || $[33] !== model.subjectName) {
        t13 = (model.subjectName || model.className || model.chapterName) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-metadata",
            children: [
                model.subjectName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "metadata-tag",
                    children: model.subjectName
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 325,
                    columnNumber: 128
                }, this),
                model.className && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "metadata-tag",
                    children: model.className
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 325,
                    columnNumber: 206
                }, this),
                model.chapterName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "metadata-tag",
                    children: model.chapterName
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 325,
                    columnNumber: 284
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 325,
            columnNumber: 74
        }, this);
        $[31] = model.chapterName;
        $[32] = model.className;
        $[33] = model.subjectName;
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    let t14;
    if ($[35] !== model.hasAR || $[36] !== model.hasAudio) {
        t14 = model.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "model-description",
            children: [
                "Click the AR icon in the viewer to experience this model in your real environment.",
                model.hasAudio && " Audio will play automatically in AR mode."
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 335,
            columnNumber: 26
        }, this);
        $[35] = model.hasAR;
        $[36] = model.hasAudio;
        $[37] = t14;
    } else {
        t14 = $[37];
    }
    let t15;
    if ($[38] !== t12 || $[39] !== t13 || $[40] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-info",
            children: [
                t12,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 344,
            columnNumber: 11
        }, this);
        $[38] = t12;
        $[39] = t13;
        $[40] = t14;
        $[41] = t15;
    } else {
        t15 = $[41];
    }
    let t16;
    if ($[42] !== t11 || $[43] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-main",
            children: [
                t11,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 354,
            columnNumber: 11
        }, this);
        $[42] = t11;
        $[43] = t15;
        $[44] = t16;
    } else {
        t16 = $[44];
    }
    let t17;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "sidebar-title",
            children: "3D Models"
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 363,
            columnNumber: 11
        }, this);
        $[45] = t17;
    } else {
        t17 = $[45];
    }
    let t18;
    if ($[46] !== allModels || $[47] !== model.modelName || $[48] !== onSelectModel) {
        let t19;
        if ($[50] !== model.modelName || $[51] !== onSelectModel) {
            t19 = ({
                "ModelViewer[allModels.map()]": (m, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `sidebar-model-item ${m.modelName === model.modelName ? "active" : ""}`,
                        onClick: {
                            "ModelViewer[allModels.map() > <div>.onClick]": ()=>onSelectModel(m)
                        }["ModelViewer[allModels.map() > <div>.onClick]"],
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "sidebar-model-image",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: m.posterImage || "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" || "/placeholder.svg",
                                        alt: m.modelName
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ModelViewer.jsx",
                                        lineNumber: 375,
                                        columnNumber: 97
                                    }, this),
                                    (m.hasAR || m.hasAudio) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "sidebar-badges",
                                        children: [
                                            m.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "mini-badge",
                                                children: "AR"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ModelViewer.jsx",
                                                lineNumber: 375,
                                                columnNumber: 326
                                            }, this),
                                            m.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "mini-badge",
                                                children: "🔊"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ModelViewer.jsx",
                                                lineNumber: 375,
                                                columnNumber: 380
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ModelViewer.jsx",
                                        lineNumber: 375,
                                        columnNumber: 282
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ModelViewer.jsx",
                                lineNumber: 375,
                                columnNumber: 60
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "sidebar-model-name",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: m.modelName
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ModelViewer.jsx",
                                    lineNumber: 375,
                                    columnNumber: 468
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ModelViewer.jsx",
                                lineNumber: 375,
                                columnNumber: 432
                            }, this)
                        ]
                    }, m.modelId || index, true, {
                        fileName: "[project]/app/components/ModelViewer.jsx",
                        lineNumber: 373,
                        columnNumber: 55
                    }, this)
            })["ModelViewer[allModels.map()]"];
            $[50] = model.modelName;
            $[51] = onSelectModel;
            $[52] = t19;
        } else {
            t19 = $[52];
        }
        t18 = allModels.map(t19);
        $[46] = allModels;
        $[47] = model.modelName;
        $[48] = onSelectModel;
        $[49] = t18;
    } else {
        t18 = $[49];
    }
    let t19;
    if ($[53] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-sidebar",
            children: [
                t17,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "model-list-sidebar",
                    children: t18
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 393,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 393,
            columnNumber: 11
        }, this);
        $[53] = t18;
        $[54] = t19;
    } else {
        t19 = $[54];
    }
    let t20;
    if ($[55] !== t16 || $[56] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-content",
            children: [
                t16,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 401,
            columnNumber: 11
        }, this);
        $[55] = t16;
        $[56] = t19;
        $[57] = t20;
    } else {
        t20 = $[57];
    }
    let t21;
    if ($[58] !== t20 || $[59] !== t8) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-viewer-container",
            children: [
                t8,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 410,
            columnNumber: 11
        }, this);
        $[58] = t20;
        $[59] = t8;
        $[60] = t21;
    } else {
        t21 = $[60];
    }
    return t21;
}
_s(ModelViewer, "J7PPXooW06IQ11rfabbvgk72KFw=");
_c = ModelViewer;
var _c;
__turbopack_context__.k.register(_c, "ModelViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/Loader.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
;
function Loader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "b81aa8ec924bcafe35a22da050a828ba36ba77a71f4581b08fc56e79008a69c3") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b81aa8ec924bcafe35a22da050a828ba36ba77a71f4581b08fc56e79008a69c3";
    }
    const { message: t1 } = t0;
    const message = t1 === undefined ? "Loading..." : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "spinner"
        }, void 0, false, {
            fileName: "[project]/app/components/Loader.jsx",
            lineNumber: 17,
            columnNumber: 10
        }, this);
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] !== message) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "loader-container",
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "loader-message",
                    children: message
                }, void 0, false, {
                    fileName: "[project]/app/components/Loader.jsx",
                    lineNumber: 24,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Loader.jsx",
            lineNumber: 24,
            columnNumber: 10
        }, this);
        $[2] = message;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    return t3;
}
_c = Loader;
var _c;
__turbopack_context__.k.register(_c, "Loader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ErrorMessage.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ErrorMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
function ErrorMessage(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "6d5adadf97a795c427c2eaba2423f49139587accf735322ca2c2ebe543953fe2") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6d5adadf97a795c427c2eaba2423f49139587accf735322ca2c2ebe543953fe2";
    }
    const { message, onRetry } = t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "error-icon",
            children: "⚠️"
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 20,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "error-title",
            children: "Oops! Something went wrong"
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 21,
            columnNumber: 10
        }, this);
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    let t3;
    if ($[3] !== message) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "error-message",
            children: message
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 30,
            columnNumber: 10
        }, this);
        $[3] = message;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== onRetry) {
        t4 = onRetry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "retry-button",
            onClick: onRetry,
            children: "Try Again"
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 38,
            columnNumber: 21
        }, this);
        $[5] = onRetry;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== t3 || $[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "error-container",
            children: [
                t1,
                t2,
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 46,
            columnNumber: 10
        }, this);
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_c = ErrorMessage;
var _c;
__turbopack_context__.k.register(_c, "ErrorMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/QRScanner.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QRScanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html5$2d$qrcode$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/html5-qrcode/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html5$2d$qrcode$2f$esm$2f$html5$2d$qrcode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/html5-qrcode/esm/html5-qrcode.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function QRScanner({ onScanSuccess, onClose }) {
    _s();
    const [scanning, setScanning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [cameraPermission, setCameraPermission] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const scannerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const html5QrCodeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QRScanner.useEffect": ()=>{
            requestCameraPermission();
            return ({
                "QRScanner.useEffect": ()=>{
                    stopScanning();
                }
            })["QRScanner.useEffect"];
        }
    }["QRScanner.useEffect"], []);
    const requestCameraPermission = async ()=>{
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: true
            });
            stream.getTracks().forEach((track)=>track.stop());
            setCameraPermission(true);
            startScanning();
        } catch (err) {
            console.error("Camera permission error:", err);
            setCameraPermission(false);
            setError("Camera access denied. Please allow camera permission to scan QR codes.");
        }
    };
    const startScanning = async ()=>{
        try {
            const html5QrCode = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html5$2d$qrcode$2f$esm$2f$html5$2d$qrcode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Html5Qrcode"]("qr-reader");
            html5QrCodeRef.current = html5QrCode;
            await html5QrCode.start({
                facingMode: "environment"
            }, {
                fps: 10,
                qrbox: {
                    width: 250,
                    height: 250
                },
                aspectRatio: 1.0
            }, (decodedText)=>{
                console.log("[v0] QR Code scanned:", decodedText);
                stopScanning();
                onScanSuccess(decodedText);
            }, (errorMessage)=>{
            // Silent error for scanning process
            });
            setScanning(true);
            setError(null);
        } catch (err_0) {
            console.error("Error starting scanner:", err_0);
            setError("Failed to start camera. Please try again.");
            setScanning(false);
        }
    };
    const stopScanning = async ()=>{
        if (html5QrCodeRef.current && scanning) {
            try {
                await html5QrCodeRef.current.stop();
                html5QrCodeRef.current = null;
                setScanning(false);
            } catch (err_1) {
                console.error("Error stopping scanner:", err_1);
            }
        }
    };
    const handleClose = async ()=>{
        await stopScanning();
        onClose();
    };
    const handleRetry = async ()=>{
        setError(null);
        await stopScanning();
        requestCameraPermission();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "qr-scanner-overlay",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "qr-scanner-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "qr-scanner-header",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            children: "Scan QR Code"
                        }, void 0, false, {
                            fileName: "[project]/app/components/QRScanner.jsx",
                            lineNumber: 86,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "qr-close-button",
                            onClick: handleClose,
                            "aria-label": "Close Scanner",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "24",
                                height: "24",
                                viewBox: "0 0 24 24",
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M18 6L6 18M6 6l12 12"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/QRScanner.jsx",
                                    lineNumber: 89,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/QRScanner.jsx",
                                lineNumber: 88,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/QRScanner.jsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/QRScanner.jsx",
                    lineNumber: 85,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "qr-scanner-content",
                    children: error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "qr-error-state",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "64",
                                height: "64",
                                viewBox: "0 0 24 24",
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        cx: "12",
                                        cy: "12",
                                        r: "10"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/QRScanner.jsx",
                                        lineNumber: 97,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M12 8v4m0 4h.01"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/QRScanner.jsx",
                                        lineNumber: 98,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/QRScanner.jsx",
                                lineNumber: 96,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "qr-error-message",
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/app/components/QRScanner.jsx",
                                lineNumber: 100,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "qr-error-actions",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "qr-retry-button",
                                        onClick: handleRetry,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 24 24",
                                                fill: "none",
                                                stroke: "currentColor",
                                                strokeWidth: "2",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/QRScanner.jsx",
                                                    lineNumber: 104,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/QRScanner.jsx",
                                                lineNumber: 103,
                                                columnNumber: 19
                                            }, this),
                                            "Retry"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/QRScanner.jsx",
                                        lineNumber: 102,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "qr-back-button",
                                        onClick: handleClose,
                                        children: "Back to Models"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/QRScanner.jsx",
                                        lineNumber: 108,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/QRScanner.jsx",
                                lineNumber: 101,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/QRScanner.jsx",
                        lineNumber: 95,
                        columnNumber: 20
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                id: "qr-reader",
                                ref: scannerRef,
                                className: "qr-reader"
                            }, void 0, false, {
                                fileName: "[project]/app/components/QRScanner.jsx",
                                lineNumber: 113,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "qr-instructions",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "Position the QR code within the frame to scan"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/QRScanner.jsx",
                                        lineNumber: 115,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "qr-instructions-sub",
                                        children: "The QR code should contain a URL to a 3D model"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/QRScanner.jsx",
                                        lineNumber: 116,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/QRScanner.jsx",
                                lineNumber: 114,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                }, void 0, false, {
                    fileName: "[project]/app/components/QRScanner.jsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/QRScanner.jsx",
            lineNumber: 84,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/QRScanner.jsx",
        lineNumber: 83,
        columnNumber: 10
    }, this);
}
_s(QRScanner, "Z6Pj20/w6WqHpKlVzM8pZJQka50=");
_c = QRScanner;
var _c;
__turbopack_context__.k.register(_c, "QRScanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ARModelViewer.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ARModelViewer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ARModelViewer({ modelUrl, onClose }) {
    _s();
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isValidating, setIsValidating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ARModelViewer.useEffect": ()=>{
            try {
                const urlObj = new URL(modelUrl);
                const validExtensions = [
                    ".glb",
                    ".gltf"
                ];
                const hasValidExtension = validExtensions.some({
                    "ARModelViewer.useEffect.hasValidExtension": (ext)=>modelUrl.toLowerCase().includes(ext)
                }["ARModelViewer.useEffect.hasValidExtension"]);
                if (!hasValidExtension) {
                    setError("Invalid model format. Only GLB and GLTF models are supported.");
                }
            } catch (err) {
                setError("Invalid model URL. Please scan a valid QR code with a 3D model URL.");
            } finally{
                setIsValidating(false);
            }
        }
    }["ARModelViewer.useEffect"], []); // Empty dependency - only run once
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ARModelViewer.useEffect": ()=>{
            if (!customElements.get("model-viewer")) {
                const script = document.createElement("script");
                script.type = "module";
                script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js";
                document.head.appendChild(script);
            }
        }
    }["ARModelViewer.useEffect"], []);
    const handleModelError = (e)=>{
        console.error("Model loading error:", e);
        setError("Failed to load the 3D model. The URL may be invalid or the model file may be corrupted.");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "ar-model-viewer-overlay",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "ar-model-viewer-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "ar-viewer-header",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            children: "AR Model Preview"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ARModelViewer.jsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "ar-close-button",
                            onClick: onClose,
                            "aria-label": "Close Viewer",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "24",
                                height: "24",
                                viewBox: "0 0 24 24",
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M18 6L6 18M6 6l12 12"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 44,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 43,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/ARModelViewer.jsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ARModelViewer.jsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "ar-viewer-content",
                    children: isValidating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ar-loader",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "spinner"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 51,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "Validating model URL..."
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 52,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ARModelViewer.jsx",
                        lineNumber: 50,
                        columnNumber: 27
                    }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ar-error-state",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "64",
                                height: "64",
                                viewBox: "0 0 24 24",
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        cx: "12",
                                        cy: "12",
                                        r: "10"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                        lineNumber: 55,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M15 9l-6 6m0-6l6 6"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                        lineNumber: 56,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 54,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "ar-error-message",
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 58,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ar-error-actions",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "ar-back-button",
                                    onClick: onClose,
                                    children: "Back"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 60,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 59,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ARModelViewer.jsx",
                        lineNumber: 53,
                        columnNumber: 30
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ar-model-wrapper",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("model-viewer", {
                                    src: modelUrl,
                                    ar: true,
                                    "ar-modes": "webxr scene-viewer quick-look",
                                    "camera-controls": true,
                                    "auto-rotate": true,
                                    "shadow-intensity": "1",
                                    style: {
                                        width: "100%",
                                        height: "500px"
                                    },
                                    onError: handleModelError
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 66,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 65,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ar-instructions",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "ar-info-card",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            width: "24",
                                            height: "24",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                    x: "2",
                                                    y: "3",
                                                    width: "20",
                                                    height: "14",
                                                    rx: "2",
                                                    ry: "2"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                                    lineNumber: 75,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M8 21h8M12 17v4"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                                    lineNumber: 76,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/ARModelViewer.jsx",
                                            lineNumber: 74,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    children: "View in AR"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                                    lineNumber: 79,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: "Click the AR button in the viewer to place this model in your real environment"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                                    lineNumber: 80,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/ARModelViewer.jsx",
                                            lineNumber: 78,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 73,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 72,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                }, void 0, false, {
                    fileName: "[project]/app/components/ARModelViewer.jsx",
                    lineNumber: 49,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ARModelViewer.jsx",
            lineNumber: 39,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/ARModelViewer.jsx",
        lineNumber: 38,
        columnNumber: 10
    }, this);
}
_s(ARModelViewer, "OJpowHeNxkBFF/NhKJXoWHR5/DQ=");
_c = ARModelViewer;
var _c;
__turbopack_context__.k.register(_c, "ARModelViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/services/api.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Mock API service - Replace with your actual API endpoint
__turbopack_context__.s([
    "fetch3dModels",
    ()=>fetch3dModels,
    "getFeaturedModels",
    ()=>getFeaturedModels
]);
const API_BASE_URL = "https://prod-api.melzoguru.in";
const MODELS_PER_PAGE = 10;
// Static featured models with audio (always shown first)
const staticFeaturedModels = [
    {
        modelId: "static-1",
        modelName: "Astronaut",
        URL: "https://modelviewer.dev/shared-assets/models/Astronaut.glb",
        iosModelUrl: "https://modelviewer.dev/shared-assets/models/Astronaut.usdz",
        posterImage: "https://modelviewer.dev/shared-assets/models/Astronaut.webp",
        audioLink: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
        modelSize: 4.2,
        dracoSize: 2000,
        hasAR: true,
        hasAudio: true,
        subjectName: "Space Science",
        className: "Featured"
    },
    {
        modelId: "static-2",
        modelName: "RobotExpressive",
        URL: "https://modelviewer.dev/shared-assets/models/RobotExpressive.glb",
        iosModelUrl: null,
        posterImage: "https://modelviewer.dev/shared-assets/models/RobotExpressive.webp",
        audioLink: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
        modelSize: 5.1,
        dracoSize: 2500,
        hasAR: true,
        hasAudio: true,
        subjectName: "Robotics",
        className: "Featured"
    },
    {
        modelId: "static-3",
        modelName: "Neil Armstrong",
        URL: "https://modelviewer.dev/shared-assets/models/NeilArmstrong.glb",
        iosModelUrl: "https://modelviewer.dev/shared-assets/models/NeilArmstrong.usdz",
        posterImage: "https://modelviewer.dev/shared-assets/models/NeilArmstrong.webp",
        audioLink: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
        modelSize: 3.8,
        dracoSize: 1800,
        hasAR: true,
        hasAudio: true,
        subjectName: "History",
        className: "Featured"
    }
];
function getFeaturedModels() {
    return staticFeaturedModels;
}
async function fetch3dModels(page = 1) {
    try {
        const response = await fetch(`${API_BASE_URL}/fetchAllScanModels?page=${page}`);
        if (!response.ok) {
            throw new Error("API request failed");
        }
        const data = await response.json();
        const transformedModels = (data.models || []).map((model)=>({
                ...model,
                hasAR: true,
                hasAudio: !!model.audioLink
            }));
        return {
            models: transformedModels,
            totalCount: data.totalModels || 0,
            isAllModelsFetched: data.isAllModelsFetched || false
        };
    } catch (error) {
        console.error("API fetch failed:", error);
        return {
            models: [],
            totalCount: 0,
            isAllModelsFetched: true,
            error: error.message
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Header$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/Header.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelList$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ModelList.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ModelViewer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Loader$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/Loader.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ErrorMessage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ErrorMessage.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$QRScanner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/QRScanner.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ARModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ARModelViewer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/services/api.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function Page() {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pageFromUrl = Number.parseInt(searchParams.get("page")) || 1;
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [filteredModels, setFilteredModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [featuredModels, setFeaturedModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedModel, setSelectedModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(pageFromUrl);
    const [totalCount, setTotalCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showQRScanner, setShowQRScanner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showARViewer, setShowARViewer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [scannedModelUrl, setScannedModelUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            setFeaturedModels((0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFeaturedModels"])());
        }
    }["Page.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            loadModels(pageFromUrl);
        }
    }["Page.useEffect"], [
        pageFromUrl
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            if (searchQuery.trim()) {
                const allModels = [
                    ...featuredModels,
                    ...models
                ];
                const filtered = allModels.filter({
                    "Page.useEffect.filtered": (model)=>model.modelName.toLowerCase().includes(searchQuery.toLowerCase().trim())
                }["Page.useEffect.filtered"]);
                setFilteredModels(filtered);
            } else {
                setFilteredModels(models);
            }
        }
    }["Page.useEffect"], [
        searchQuery,
        models,
        featuredModels
    ]);
    const loadModels = async (page = 1)=>{
        try {
            setLoading(true);
            setError(null);
            const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch3dModels"])(page);
            if (response.models && response.models.length > 0) {
                setModels(response.models);
                setFilteredModels(response.models);
                setCurrentPage(page);
                setTotalCount(response.totalCount);
            } else {
                setModels([]);
                setFilteredModels([]);
                setError(response.error || "No models available at the moment.");
            }
            setLoading(false);
        } catch (err) {
            console.error("Error loading models:", err);
            setError("Failed to load 3D models. Please try again later.");
            setLoading(false);
        }
    };
    const handlePageChange = (newPage)=>{
        router.push(`?page=${newPage}`);
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    const handleModelSelect = (model_0)=>{
        setSelectedModel(model_0);
    };
    const handleBackToList = ()=>{
        setSelectedModel(null);
    };
    const handleQRScanClick = ()=>{
        setShowQRScanner(true);
    };
    const handleQRScanSuccess = (url)=>{
        setScannedModelUrl(url);
        setShowQRScanner(false);
        setShowARViewer(true);
    };
    const handleCloseQRScanner = ()=>{
        setShowQRScanner(false);
    };
    const handleCloseARViewer = ()=>{
        setShowARViewer(false);
        setScannedModelUrl(null);
    };
    const handleSearch = (query)=>{
        setSearchQuery(query);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "app",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Header$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onQRScanClick: handleQRScanClick,
                onSearch: handleSearch,
                searchQuery: searchQuery
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "main-content",
                children: loading && models.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Loader$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    message: "Loading 3D Models..."
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 102,
                    columnNumber: 43
                }, this) : error && models.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ErrorMessage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    message: error,
                    onRetry: ()=>loadModels(currentPage)
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 102,
                    columnNumber: 118
                }, this) : selectedModel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    model: selectedModel,
                    onBack: handleBackToList,
                    allModels: filteredModels,
                    onSelectModel: handleModelSelect
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 102,
                    columnNumber: 209
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelList$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        models: filteredModels,
                        onSelectModel: handleModelSelect,
                        currentPage: currentPage,
                        totalCount: totalCount,
                        onPageChange: handlePageChange,
                        loading: loading,
                        searchQuery: searchQuery,
                        sectionTitle: searchQuery ? "Search Results" : "All AR Models",
                        showPagination: !searchQuery
                    }, void 0, false, {
                        fileName: "[project]/app/page.js",
                        lineNumber: 112,
                        columnNumber: 13
                    }, this)
                }, void 0, false)
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            showQRScanner && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$QRScanner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onScanSuccess: handleQRScanSuccess,
                onClose: handleCloseQRScanner
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 116,
                columnNumber: 25
            }, this),
            showARViewer && scannedModelUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ARModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                modelUrl: scannedModelUrl,
                onClose: handleCloseARViewer
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 118,
                columnNumber: 43
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.js",
        lineNumber: 98,
        columnNumber: 10
    }, this);
}
_s(Page, "BOW2AmrPu1B7aRMpY2csEOUvIhA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = Page;
var _c;
__turbopack_context__.k.register(_c, "Page");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_942f28d2._.js.map