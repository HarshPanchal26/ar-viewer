(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/Header.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function Header(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(40);
    if ($[0] !== "b98ecc6e5aff7504e4a63ad432c51e6963d2af26c650086f4c4ab39ab41cc137") {
        for(let $i = 0; $i < 40; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b98ecc6e5aff7504e4a63ad432c51e6963d2af26c650086f4c4ab39ab41cc137";
    }
    const { onQRScanClick, onSearch, searchQuery } = t0;
    const [localSearchQuery, setLocalSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(searchQuery || "");
    const [isSearchOpen, setIsSearchOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "Header[handleSearchChange]": (e)=>{
                setLocalSearchQuery(e.target.value);
            }
        })["Header[handleSearchChange]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const handleSearchChange = t1;
    let t2;
    if ($[2] !== localSearchQuery || $[3] !== onSearch) {
        t2 = ({
            "Header[handleSearchSubmit]": (e_0)=>{
                e_0.preventDefault();
                if (onSearch) {
                    onSearch(localSearchQuery);
                }
            }
        })["Header[handleSearchSubmit]"];
        $[2] = localSearchQuery;
        $[3] = onSearch;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const handleSearchSubmit = t2;
    let t3;
    if ($[5] !== onSearch) {
        t3 = ({
            "Header[handleClearSearch]": ()=>{
                setLocalSearchQuery("");
                if (onSearch) {
                    onSearch("");
                }
                setIsSearchOpen(false);
            }
        })["Header[handleClearSearch]"];
        $[5] = onSearch;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const handleClearSearch = t3;
    let t4;
    if ($[7] !== isSearchOpen) {
        t4 = ({
            "Header[toggleSearch]": ()=>{
                setIsSearchOpen(!isSearchOpen);
            }
        })["Header[toggleSearch]"];
        $[7] = isSearchOpen;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const toggleSearch = t4;
    let t5;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
            offset: "0%",
            style: {
                stopColor: "#ff6b35",
                stopOpacity: 1
            }
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    let t7;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "logo-container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                viewBox: "0 0 180 50",
                className: "logo-svg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                            id: "logoGradient",
                            x1: "0%",
                            y1: "0%",
                            x2: "100%",
                            y2: "0%",
                            children: [
                                t5,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                    offset: "100%",
                                    style: {
                                        stopColor: "#ff8c5a",
                                        stopOpacity: 1
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 93,
                                    columnNumber: 167
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 93,
                            columnNumber: 95
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 93,
                        columnNumber: 89
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: "0",
                        y: "5",
                        width: "10",
                        height: "40",
                        rx: "2",
                        fill: "url(#logoGradient)"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 96,
                        columnNumber: 42
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: "13",
                        y: "12",
                        width: "6",
                        height: "33",
                        rx: "1",
                        fill: "url(#logoGradient)",
                        opacity: "0.7"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 96,
                        columnNumber: 118
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                        x: "30",
                        y: "37",
                        className: "logo-text",
                        children: "melzo"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 96,
                        columnNumber: 209
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 93,
                columnNumber: 42
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 93,
            columnNumber: 10
        }, this);
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "header-divider"
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[10] = t6;
        $[11] = t7;
    } else {
        t6 = $[10];
        t7 = $[11];
    }
    let t8;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "header-title-section",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "header-title",
                    children: "AR Lab"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 106,
                    columnNumber: 48
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "header-subtitle",
                    children: "Augmented Reality Experience"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 106,
                    columnNumber: 88
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 106,
            columnNumber: 10
        }, this);
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== localSearchQuery) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Search models...",
            value: localSearchQuery,
            onChange: handleSearchChange,
            className: "search-input"
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 113,
            columnNumber: 10
        }, this);
        $[13] = localSearchQuery;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== handleClearSearch || $[16] !== localSearchQuery) {
        t10 = localSearchQuery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: handleClearSearch,
            className: "clear-search-btn",
            "aria-label": "Clear search",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: "18",
                height: "18",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: "18",
                        y1: "6",
                        x2: "6",
                        y2: "18"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 121,
                        columnNumber: 234
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: "6",
                        y1: "6",
                        x2: "18",
                        y2: "18"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 121,
                        columnNumber: 272
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 121,
                columnNumber: 136
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 121,
            columnNumber: 31
        }, this);
        $[15] = handleClearSearch;
        $[16] = localSearchQuery;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            className: "search-btn",
            "aria-label": "Search",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: "20",
                height: "20",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: "11",
                        cy: "11",
                        r: "8"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 130,
                        columnNumber: 174
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "m21 21-4.35-4.35"
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 130,
                        columnNumber: 206
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 130,
                columnNumber: 76
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 130,
            columnNumber: 11
        }, this);
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== handleSearchSubmit || $[20] !== t10 || $[21] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            className: "search-form desktop-search",
            onSubmit: handleSearchSubmit,
            children: [
                t9,
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 137,
            columnNumber: 11
        }, this);
        $[19] = handleSearchSubmit;
        $[20] = t10;
        $[21] = t9;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "22",
            height: "22",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "11",
                    cy: "11",
                    r: "8"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 147,
                    columnNumber: 109
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "m21 21-4.35-4.35"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 147,
                    columnNumber: 141
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 147,
            columnNumber: 11
        }, this);
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== toggleSearch) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "icon-btn mobile-search-toggle",
            onClick: toggleSearch,
            "aria-label": "Toggle search",
            children: t13
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 154,
            columnNumber: 11
        }, this);
        $[24] = toggleSearch;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] !== onQRScanClick) {
        t15 = onQRScanClick && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "icon-btn qr-scan-button",
            onClick: onQRScanClick,
            "aria-label": "Scan QR Code",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "22",
                    height: "22",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "3",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 162,
                            columnNumber: 220
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "14",
                            y: "3",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 162,
                            columnNumber: 261
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "14",
                            y: "14",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 162,
                            columnNumber: 303
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "14",
                            width: "7",
                            height: "7"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 162,
                            columnNumber: 346
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 162,
                    columnNumber: 122
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "btn-text",
                    children: "Scan QR"
                }, void 0, false, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 162,
                    columnNumber: 394
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 162,
            columnNumber: 28
        }, this);
        $[26] = onQRScanClick;
        $[27] = t15;
    } else {
        t15 = $[27];
    }
    let t16;
    if ($[28] !== t12 || $[29] !== t14 || $[30] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "header-content",
            children: [
                t6,
                t7,
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "header-actions",
                    children: [
                        t12,
                        t14,
                        t15
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/Header.jsx",
                    lineNumber: 170,
                    columnNumber: 55
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 170,
            columnNumber: 11
        }, this);
        $[28] = t12;
        $[29] = t14;
        $[30] = t15;
        $[31] = t16;
    } else {
        t16 = $[31];
    }
    let t17;
    if ($[32] !== handleClearSearch || $[33] !== handleSearchSubmit || $[34] !== isSearchOpen || $[35] !== localSearchQuery) {
        t17 = isSearchOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mobile-search-dropdown",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                className: "search-form",
                onSubmit: handleSearchSubmit,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        placeholder: "Search models...",
                        value: localSearchQuery,
                        onChange: handleSearchChange,
                        className: "search-input",
                        autoFocus: true
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 180,
                        columnNumber: 127
                    }, this),
                    localSearchQuery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleClearSearch,
                        className: "clear-search-btn",
                        "aria-label": "Clear search",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "18",
                            height: "18",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                    x1: "18",
                                    y1: "6",
                                    x2: "6",
                                    y2: "18"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 180,
                                    columnNumber: 500
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                    x1: "6",
                                    y1: "6",
                                    x2: "18",
                                    y2: "18"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 180,
                                    columnNumber: 538
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 180,
                            columnNumber: 402
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 180,
                        columnNumber: 297
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "search-btn",
                        "aria-label": "Search",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "20",
                            height: "20",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                    cx: "11",
                                    cy: "11",
                                    r: "8"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 180,
                                    columnNumber: 755
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "m21 21-4.35-4.35"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Header.jsx",
                                    lineNumber: 180,
                                    columnNumber: 787
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/Header.jsx",
                            lineNumber: 180,
                            columnNumber: 657
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/Header.jsx",
                        lineNumber: 180,
                        columnNumber: 592
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/Header.jsx",
                lineNumber: 180,
                columnNumber: 67
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 180,
            columnNumber: 27
        }, this);
        $[32] = handleClearSearch;
        $[33] = handleSearchSubmit;
        $[34] = isSearchOpen;
        $[35] = localSearchQuery;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    let t18;
    if ($[37] !== t16 || $[38] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: "header",
            children: [
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Header.jsx",
            lineNumber: 191,
            columnNumber: 11
        }, this);
        $[37] = t16;
        $[38] = t17;
        $[39] = t18;
    } else {
        t18 = $[39];
    }
    return t18;
}
_s(Header, "hQa3r9ax3LCilIwlmfoq+4Tm6UY=");
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ModelList.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModelList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
function ModelList(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "f1686d83c7120c69ca43c1b6fe8a5dc42d5e5cb6b95e6463ac1bfa7c2dd1dfa2") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f1686d83c7120c69ca43c1b6fe8a5dc42d5e5cb6b95e6463ac1bfa7c2dd1dfa2";
    }
    const { models, onSelectModel, currentPage, totalPages, onPageChange, loading, searchQuery } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            children: "Discover AR Models"
        }, void 0, false, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 24,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const t2 = searchQuery && `Search results for "${searchQuery}" - `;
    const t3 = models.length !== 1 ? "s" : "";
    let t4;
    if ($[2] !== models.length || $[3] !== t2 || $[4] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-list-header",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "header-left",
                children: [
                    t1,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "model-count",
                        children: [
                            t2,
                            models.length,
                            " model",
                            t3
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ModelList.jsx",
                        lineNumber: 33,
                        columnNumber: 78
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ModelList.jsx",
                lineNumber: 33,
                columnNumber: 45
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 33,
            columnNumber: 10
        }, this);
        $[2] = models.length;
        $[3] = t2;
        $[4] = t3;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== models || $[7] !== onSelectModel) {
        let t6;
        if ($[9] !== onSelectModel) {
            t6 = ({
                "ModelList[models.map()]": (model, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "model-card",
                        onClick: {
                            "ModelList[models.map() > <div>.onClick]": ()=>onSelectModel(model)
                        }["ModelList[models.map() > <div>.onClick]"],
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "model-card-image",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: model.posterImage || "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" || "/placeholder.svg" || "/placeholder.svg",
                                        alt: model.modelName,
                                        loading: "lazy"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 48,
                                        columnNumber: 89
                                    }, this),
                                    (model.hasAR || model.hasAudio) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "card-badges",
                                        children: [
                                            model.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "card-badge",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        width: "12",
                                                        height: "12",
                                                        viewBox: "0 0 24 24",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        strokeWidth: "2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                                x: "2",
                                                                y: "3",
                                                                width: "20",
                                                                height: "14",
                                                                rx: "2",
                                                                ry: "2"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 48,
                                                                columnNumber: 499
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M8 21h8M12 17v4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 48,
                                                                columnNumber: 556
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/components/ModelList.jsx",
                                                        lineNumber: 48,
                                                        columnNumber: 401
                                                    }, this),
                                                    "AR"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/ModelList.jsx",
                                                lineNumber: 48,
                                                columnNumber: 372
                                            }, this),
                                            model.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "card-badge",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        width: "12",
                                                        height: "12",
                                                        viewBox: "0 0 24 24",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        strokeWidth: "2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M11 5L6 9H2v6h4l5 4V5z"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 48,
                                                                columnNumber: 746
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/ModelList.jsx",
                                                                lineNumber: 48,
                                                                columnNumber: 781
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/components/ModelList.jsx",
                                                        lineNumber: 48,
                                                        columnNumber: 648
                                                    }, this),
                                                    "Audio"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/ModelList.jsx",
                                                lineNumber: 48,
                                                columnNumber: 619
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 48,
                                        columnNumber: 327
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "model-card-overlay",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "view-model-text",
                                            children: "View Model"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ModelList.jsx",
                                            lineNumber: 48,
                                            columnNumber: 915
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ModelList.jsx",
                                        lineNumber: 48,
                                        columnNumber: 879
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ModelList.jsx",
                                lineNumber: 48,
                                columnNumber: 55
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "model-card-content",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "model-card-title",
                                    children: model.modelName
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ModelList.jsx",
                                    lineNumber: 48,
                                    columnNumber: 1014
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ModelList.jsx",
                                lineNumber: 48,
                                columnNumber: 978
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/app/components/ModelList.jsx",
                        lineNumber: 46,
                        columnNumber: 54
                    }, this)
            })["ModelList[models.map()]"];
            $[9] = onSelectModel;
            $[10] = t6;
        } else {
            t6 = $[10];
        }
        t5 = models.map(t6);
        $[6] = models;
        $[7] = onSelectModel;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-grid",
            children: t5
        }, void 0, false, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 64,
            columnNumber: 10
        }, this);
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== currentPage || $[14] !== loading || $[15] !== onPageChange || $[16] !== totalPages) {
        t7 = totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pagination-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "pagination-btn",
                    onClick: {
                        "ModelList[<button>.onClick]": ()=>onPageChange(currentPage - 1)
                    }["ModelList[<button>.onClick]"],
                    disabled: currentPage === 1 || loading,
                    children: "Previous"
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelList.jsx",
                    lineNumber: 72,
                    columnNumber: 66
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pagination-numbers",
                    children: Array.from({
                        length: totalPages
                    }, _ModelListArrayFrom).map({
                        "ModelList[(anonymous)()]": (page)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: `pagination-number ${page === currentPage ? "active" : ""}`,
                                onClick: {
                                    "ModelList[(anonymous)() > <button>.onClick]": ()=>onPageChange(page)
                                }["ModelList[(anonymous)() > <button>.onClick]"],
                                disabled: loading,
                                children: page
                            }, page, false, {
                                fileName: "[project]/app/components/ModelList.jsx",
                                lineNumber: 77,
                                columnNumber: 47
                            }, this)
                    }["ModelList[(anonymous)()]"])
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelList.jsx",
                    lineNumber: 74,
                    columnNumber: 98
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "pagination-btn",
                    onClick: {
                        "ModelList[<button>.onClick]": ()=>onPageChange(currentPage + 1)
                    }["ModelList[<button>.onClick]"],
                    disabled: currentPage === totalPages || loading,
                    children: "Next"
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelList.jsx",
                    lineNumber: 80,
                    columnNumber: 46
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 72,
            columnNumber: 28
        }, this);
        $[13] = currentPage;
        $[14] = loading;
        $[15] = onPageChange;
        $[16] = totalPages;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    let t8;
    if ($[18] !== t4 || $[19] !== t6 || $[20] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-list-container",
            children: [
                t4,
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelList.jsx",
            lineNumber: 93,
            columnNumber: 10
        }, this);
        $[18] = t4;
        $[19] = t6;
        $[20] = t7;
        $[21] = t8;
    } else {
        t8 = $[21];
    }
    return t8;
}
_c = ModelList;
function _ModelListArrayFrom(_, i) {
    return i + 1;
}
var _c;
__turbopack_context__.k.register(_c, "ModelList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ModelViewerComponent.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client"
// import { useEffect } from "react"
// export default function ModelViewerComponent({ posterImage, modelUrl, modelName }) {
//   useEffect(() => {
//     // Dynamically load model-viewer script if not already loaded
//     if (!window.customElements.get("model-viewer")) {
//       const script = document.createElement("script")
//       script.type = "module"
//       script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.3.0/model-viewer.min.js"
//       document.head.appendChild(script)
//     }
//   }, [])
//   return (
//     <model-viewer
//       poster={posterImage}
//       src={modelUrl}
//       alt={modelName}
//       ar
//       ar-modes="webxr scene-viewer quick-look"
//       camera-controls
//       autoplay
//       enable-pan
//       style={{
//         width: "100%",
//         height: "100%",
//         display: "block",
//         background: "#1c1c1c",
//       }}
//     />
//   )
// }
__turbopack_context__.s([
    "default",
    ()=>ModelViewerComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ModelViewerComponent(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24);
    if ($[0] !== "7ffb41cbb0d7c5a5bd65d65c55b342cf6f7b75977c6abb73f4644207b1dd4488") {
        for(let $i = 0; $i < 24; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7ffb41cbb0d7c5a5bd65d65c55b342cf6f7b75977c6abb73f4644207b1dd4488";
    }
    const { posterImage, modelUrl, modelName, audioUrl, iosModelUrl } = t0;
    const modelViewerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const audioRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isARActive, setIsARActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [arSupported, setArSupported] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ModelViewerComponent[useEffect()]": ()=>{
                if (!window.customElements.get("model-viewer")) {
                    const script = document.createElement("script");
                    script.type = "module";
                    script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.3.0/model-viewer.min.js";
                    document.head.appendChild(script);
                }
                if (modelViewerRef.current) {
                    const checkARSupport = {
                        "ModelViewerComponent[useEffect() > checkARSupport]": async ()=>{
                            if (navigator.xr) {
                                const supported = await navigator.xr.isSessionSupported("immersive-ar");
                                setArSupported(supported);
                            } else {
                                if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
                                    setArSupported(true);
                                } else {
                                    if (/Android/.test(navigator.userAgent)) {
                                        setArSupported(true);
                                    }
                                }
                            }
                        }
                    }["ModelViewerComponent[useEffect() > checkARSupport]"];
                    checkARSupport();
                }
            }
        })["ModelViewerComponent[useEffect()]"];
        t2 = [];
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    let t4;
    if ($[3] !== audioUrl) {
        t3 = ({
            "ModelViewerComponent[useEffect()]": ()=>{
                const modelViewer = modelViewerRef.current;
                if (!modelViewer) {
                    return;
                }
                const handleARStatus = {
                    "ModelViewerComponent[useEffect() > handleARStatus]": (event)=>{
                        console.log("[v0] AR Status:", event.type);
                        if (event.type === "ar-status") {
                            setIsARActive(event.detail.status === "session-started");
                        }
                    }
                }["ModelViewerComponent[useEffect() > handleARStatus]"];
                const handleQuickLookButtonTapped = {
                    "ModelViewerComponent[useEffect() > handleQuickLookButtonTapped]": ()=>{
                        console.log("[v0] Quick Look AR activated");
                        setIsARActive(true);
                        if (audioRef.current && audioUrl) {
                            audioRef.current.play().catch(_ModelViewerComponentUseEffectHandleQuickLookButtonTappedAnonymous);
                        }
                    }
                }["ModelViewerComponent[useEffect() > handleQuickLookButtonTapped]"];
                modelViewer.addEventListener("ar-status", handleARStatus);
                modelViewer.addEventListener("quick-look-button-tapped", handleQuickLookButtonTapped);
                return ()=>{
                    modelViewer.removeEventListener("ar-status", handleARStatus);
                    modelViewer.removeEventListener("quick-look-button-tapped", handleQuickLookButtonTapped);
                };
            }
        })["ModelViewerComponent[useEffect()]"];
        t4 = [
            audioUrl
        ];
        $[3] = audioUrl;
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    let t6;
    if ($[6] !== audioUrl || $[7] !== isARActive) {
        t5 = ({
            "ModelViewerComponent[useEffect()]": ()=>{
                if (isARActive && audioRef.current && audioUrl) {
                    console.log("[v0] Playing audio in AR mode");
                    audioRef.current.play().catch(_ModelViewerComponentUseEffectAnonymous);
                } else {
                    if (!isARActive && audioRef.current) {
                        audioRef.current.pause();
                        audioRef.current.currentTime = 0;
                    }
                }
            }
        })["ModelViewerComponent[useEffect()]"];
        t6 = [
            isARActive,
            audioUrl
        ];
        $[6] = audioUrl;
        $[7] = isARActive;
        $[8] = t5;
        $[9] = t6;
    } else {
        t5 = $[8];
        t6 = $[9];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    const t7 = iosModelUrl || modelUrl;
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            width: "100%",
            height: "100%",
            display: "block",
            background: "#1c1c1c"
        };
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== modelName || $[12] !== modelUrl || $[13] !== posterImage || $[14] !== t7) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("model-viewer", {
            ref: modelViewerRef,
            poster: posterImage,
            src: modelUrl,
            "ios-src": t7,
            alt: modelName,
            ar: true,
            "ar-modes": "webxr scene-viewer quick-look",
            "camera-controls": true,
            autoplay: true,
            "enable-pan": true,
            "shadow-intensity": "1",
            "environment-image": "neutral",
            exposure: "1",
            style: t8
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewerComponent.jsx",
            lineNumber: 183,
            columnNumber: 10
        }, this);
        $[11] = modelName;
        $[12] = modelUrl;
        $[13] = posterImage;
        $[14] = t7;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] !== audioUrl) {
        t10 = audioUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("audio", {
            ref: audioRef,
            src: audioUrl,
            loop: true,
            preload: "auto",
            style: {
                display: "none"
            }
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewerComponent.jsx",
            lineNumber: 194,
            columnNumber: 23
        }, this);
        $[16] = audioUrl;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== arSupported) {
        t11 = arSupported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                position: "absolute",
                bottom: "20px",
                left: "50%",
                transform: "translateX(-50%)",
                background: "rgba(0, 0, 0, 0.7)",
                color: "white",
                padding: "8px 16px",
                borderRadius: "20px",
                fontSize: "14px",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                zIndex: 10
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "16",
                    height: "16",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "2",
                            y: "3",
                            width: "20",
                            height: "14",
                            rx: "2",
                            ry: "2"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewerComponent.jsx",
                            lineNumber: 218,
                            columnNumber: 106
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M8 21h8M12 17v4"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewerComponent.jsx",
                            lineNumber: 218,
                            columnNumber: 163
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ModelViewerComponent.jsx",
                    lineNumber: 218,
                    columnNumber: 8
                }, this),
                "AR Available - Tap the AR button"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewerComponent.jsx",
            lineNumber: 204,
            columnNumber: 26
        }, this);
        $[18] = arSupported;
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    let t12;
    if ($[20] !== t10 || $[21] !== t11 || $[22] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t9,
                t10,
                t11
            ]
        }, void 0, true);
        $[20] = t10;
        $[21] = t11;
        $[22] = t9;
        $[23] = t12;
    } else {
        t12 = $[23];
    }
    return t12;
}
_s(ModelViewerComponent, "OZJwjXJCCswTIhy96RD5irULZQk=");
_c = ModelViewerComponent;
function _ModelViewerComponentUseEffectAnonymous(err_0) {
    return console.error("[v0] Audio play failed:", err_0);
}
function _ModelViewerComponentUseEffectHandleQuickLookButtonTappedAnonymous(err) {
    return console.error("[v0] Audio play failed:", err);
}
var _c;
__turbopack_context__.k.register(_c, "ModelViewerComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ModelViewer.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client"
// import { useState, useEffect } from "react"
// import ModelViewerComponent from "./ModelViewerComponent"
// import "../styles/model-viewer.css"
// export default function ModelViewer({ model, onBack, allModels, onSelectModel }) {
//   const [loading, setLoading] = useState(true)
//   useEffect(() => {
//     setLoading(true)
//     const timer = setTimeout(() => setLoading(false), 1000)
//     return () => clearTimeout(timer)
//   }, [model])
//   const modelUrl = model.dracoURL || model.URL
//   return (
//     <div className="model-viewer-container">
//       <div className="viewer-header">
//         <button className="back-button" onClick={onBack}>
//           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//             <path d="M19 12H5M12 19l-7-7 7-7" />
//           </svg>
//           Go Back
//         </button>
//       </div>
//       <div className="viewer-content">
//         <div className="viewer-main">
//           <div className="model-viewer-wrapper">
//             {loading && (
//               <div className="viewer-loader">
//                 <div className="spinner"></div>
//                 <p>Loading 3D Model...</p>
//               </div>
//             )}
//             <ModelViewerComponent posterImage={model.posterImage} modelUrl={modelUrl} modelName={model.modelName} />
//           </div>
//           <div className="model-info">
//             <h2 className="model-title">{model.modelName}</h2>
//           </div>
//         </div>
//         <div className="viewer-sidebar">
//           <h3 className="sidebar-title">3D Models</h3>
//           <div className="model-list-sidebar">
//             {allModels.map((m, index) => (
//               <div
//                 key={index}
//                 className={`sidebar-model-item ${m.modelName === model.modelName ? "active" : ""}`}
//                 onClick={() => onSelectModel(m)}
//               >
//                 <div className="sidebar-model-image">
//                   <img
//                     src={
//                       m.posterImage ||
//                       "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" ||
//                       "/placeholder.svg"
//                     }
//                     alt={m.modelName}
//                   />
//                 </div>
//                 <div className="sidebar-model-name">
//                   <p>{m.modelName}</p>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }
__turbopack_context__.s([
    "default",
    ()=>ModelViewer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ModelViewerComponent.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ModelViewer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(54);
    if ($[0] !== "02c082d347e67177e0ecc1c0d65c3c12a733064d438887130491e897bd5e4d64") {
        for(let $i = 0; $i < 54; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "02c082d347e67177e0ecc1c0d65c3c12a733064d438887130491e897bd5e4d64";
    }
    const { model, onBack, allModels, onSelectModel } = t0;
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ModelViewer[useEffect()]": ()=>{
                setLoading(true);
                const timer = setTimeout({
                    "ModelViewer[useEffect() > setTimeout()]": ()=>setLoading(false)
                }["ModelViewer[useEffect() > setTimeout()]"], 1000);
                return ()=>clearTimeout(timer);
            }
        })["ModelViewer[useEffect()]"];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== model) {
        t2 = [
            model
        ];
        $[2] = model;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    const modelUrl = model.dracoURL || model.URL;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "20",
            height: "20",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19 12H5M12 19l-7-7 7-7"
            }, void 0, false, {
                fileName: "[project]/app/components/ModelViewer.jsx",
                lineNumber: 124,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 124,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== onBack) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "back-button",
            onClick: onBack,
            children: [
                t3,
                "Go Back"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 131,
            columnNumber: 10
        }, this);
        $[5] = onBack;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== model.hasAR) {
        t5 = model.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "badge ar-badge",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "16",
                    height: "16",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "2",
                            y: "3",
                            width: "20",
                            height: "14",
                            rx: "2",
                            ry: "2"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 139,
                            columnNumber: 156
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M8 21h8M12 17v4"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 139,
                            columnNumber: 213
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 139,
                    columnNumber: 58
                }, this),
                "AR Enabled"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 139,
            columnNumber: 25
        }, this);
        $[7] = model.hasAR;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== model.hasAudio) {
        t6 = model.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "badge audio-badge",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "16",
                    height: "16",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M11 5L6 9H2v6h4l5 4V5z"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 147,
                            columnNumber: 162
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ModelViewer.jsx",
                            lineNumber: 147,
                            columnNumber: 197
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 147,
                    columnNumber: 64
                }, this),
                "Audio"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 147,
            columnNumber: 28
        }, this);
        $[9] = model.hasAudio;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== t5 || $[12] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-badges",
            children: [
                t5,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 155,
            columnNumber: 10
        }, this);
        $[11] = t5;
        $[12] = t6;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== t4 || $[15] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-header",
            children: [
                t4,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 164,
            columnNumber: 10
        }, this);
        $[14] = t4;
        $[15] = t7;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    let t9;
    if ($[17] !== loading) {
        t9 = loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-loader",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "spinner"
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 173,
                    columnNumber: 52
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Loading 3D Model..."
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 173,
                    columnNumber: 79
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 173,
            columnNumber: 21
        }, this);
        $[17] = loading;
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    let t10;
    if ($[19] !== model.audioUrl || $[20] !== model.iosModelUrl || $[21] !== model.modelName || $[22] !== model.posterImage || $[23] !== modelUrl) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewerComponent$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            posterImage: model.posterImage,
            modelUrl: modelUrl,
            modelName: model.modelName,
            audioUrl: model.audioUrl,
            iosModelUrl: model.iosModelUrl
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 181,
            columnNumber: 11
        }, this);
        $[19] = model.audioUrl;
        $[20] = model.iosModelUrl;
        $[21] = model.modelName;
        $[22] = model.posterImage;
        $[23] = modelUrl;
        $[24] = t10;
    } else {
        t10 = $[24];
    }
    let t11;
    if ($[25] !== t10 || $[26] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-viewer-wrapper",
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 193,
            columnNumber: 11
        }, this);
        $[25] = t10;
        $[26] = t9;
        $[27] = t11;
    } else {
        t11 = $[27];
    }
    let t12;
    if ($[28] !== model.modelName) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "model-title",
            children: model.modelName
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 202,
            columnNumber: 11
        }, this);
        $[28] = model.modelName;
        $[29] = t12;
    } else {
        t12 = $[29];
    }
    let t13;
    if ($[30] !== model.hasAR) {
        t13 = model.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "model-description",
            children: "Click the AR icon in the viewer to experience this model in your real environment. Audio will play automatically in AR mode."
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 210,
            columnNumber: 26
        }, this);
        $[30] = model.hasAR;
        $[31] = t13;
    } else {
        t13 = $[31];
    }
    let t14;
    if ($[32] !== t12 || $[33] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-info",
            children: [
                t12,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 218,
            columnNumber: 11
        }, this);
        $[32] = t12;
        $[33] = t13;
        $[34] = t14;
    } else {
        t14 = $[34];
    }
    let t15;
    if ($[35] !== t11 || $[36] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-main",
            children: [
                t11,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[35] = t11;
        $[36] = t14;
        $[37] = t15;
    } else {
        t15 = $[37];
    }
    let t16;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "sidebar-title",
            children: "3D Models"
        }, void 0, false, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 236,
            columnNumber: 11
        }, this);
        $[38] = t16;
    } else {
        t16 = $[38];
    }
    let t17;
    if ($[39] !== allModels || $[40] !== model.modelName || $[41] !== onSelectModel) {
        let t18;
        if ($[43] !== model.modelName || $[44] !== onSelectModel) {
            t18 = ({
                "ModelViewer[allModels.map()]": (m, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `sidebar-model-item ${m.modelName === model.modelName ? "active" : ""}`,
                        onClick: {
                            "ModelViewer[allModels.map() > <div>.onClick]": ()=>onSelectModel(m)
                        }["ModelViewer[allModels.map() > <div>.onClick]"],
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "sidebar-model-image",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: m.posterImage || "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg" || "/placeholder.svg" || "/placeholder.svg",
                                        alt: m.modelName
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ModelViewer.jsx",
                                        lineNumber: 248,
                                        columnNumber: 97
                                    }, this),
                                    (m.hasAR || m.hasAudio) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "sidebar-badges",
                                        children: [
                                            m.hasAR && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "mini-badge",
                                                children: "AR"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ModelViewer.jsx",
                                                lineNumber: 248,
                                                columnNumber: 348
                                            }, this),
                                            m.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "mini-badge",
                                                children: "🔊"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ModelViewer.jsx",
                                                lineNumber: 248,
                                                columnNumber: 402
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ModelViewer.jsx",
                                        lineNumber: 248,
                                        columnNumber: 304
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ModelViewer.jsx",
                                lineNumber: 248,
                                columnNumber: 60
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "sidebar-model-name",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: m.modelName
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ModelViewer.jsx",
                                    lineNumber: 248,
                                    columnNumber: 490
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ModelViewer.jsx",
                                lineNumber: 248,
                                columnNumber: 454
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/app/components/ModelViewer.jsx",
                        lineNumber: 246,
                        columnNumber: 55
                    }, this)
            })["ModelViewer[allModels.map()]"];
            $[43] = model.modelName;
            $[44] = onSelectModel;
            $[45] = t18;
        } else {
            t18 = $[45];
        }
        t17 = allModels.map(t18);
        $[39] = allModels;
        $[40] = model.modelName;
        $[41] = onSelectModel;
        $[42] = t17;
    } else {
        t17 = $[42];
    }
    let t18;
    if ($[46] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-sidebar",
            children: [
                t16,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "model-list-sidebar",
                    children: t17
                }, void 0, false, {
                    fileName: "[project]/app/components/ModelViewer.jsx",
                    lineNumber: 266,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 266,
            columnNumber: 11
        }, this);
        $[46] = t17;
        $[47] = t18;
    } else {
        t18 = $[47];
    }
    let t19;
    if ($[48] !== t15 || $[49] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "viewer-content",
            children: [
                t15,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 274,
            columnNumber: 11
        }, this);
        $[48] = t15;
        $[49] = t18;
        $[50] = t19;
    } else {
        t19 = $[50];
    }
    let t20;
    if ($[51] !== t19 || $[52] !== t8) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "model-viewer-container",
            children: [
                t8,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ModelViewer.jsx",
            lineNumber: 283,
            columnNumber: 11
        }, this);
        $[51] = t19;
        $[52] = t8;
        $[53] = t20;
    } else {
        t20 = $[53];
    }
    return t20;
}
_s(ModelViewer, "J7PPXooW06IQ11rfabbvgk72KFw=");
_c = ModelViewer;
var _c;
__turbopack_context__.k.register(_c, "ModelViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/Loader.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
;
function Loader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "b81aa8ec924bcafe35a22da050a828ba36ba77a71f4581b08fc56e79008a69c3") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b81aa8ec924bcafe35a22da050a828ba36ba77a71f4581b08fc56e79008a69c3";
    }
    const { message: t1 } = t0;
    const message = t1 === undefined ? "Loading..." : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "spinner"
        }, void 0, false, {
            fileName: "[project]/app/components/Loader.jsx",
            lineNumber: 17,
            columnNumber: 10
        }, this);
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] !== message) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "loader-container",
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "loader-message",
                    children: message
                }, void 0, false, {
                    fileName: "[project]/app/components/Loader.jsx",
                    lineNumber: 24,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Loader.jsx",
            lineNumber: 24,
            columnNumber: 10
        }, this);
        $[2] = message;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    return t3;
}
_c = Loader;
var _c;
__turbopack_context__.k.register(_c, "Loader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ErrorMessage.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ErrorMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
function ErrorMessage(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "6d5adadf97a795c427c2eaba2423f49139587accf735322ca2c2ebe543953fe2") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6d5adadf97a795c427c2eaba2423f49139587accf735322ca2c2ebe543953fe2";
    }
    const { message, onRetry } = t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "error-icon",
            children: "⚠️"
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 20,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "error-title",
            children: "Oops! Something went wrong"
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 21,
            columnNumber: 10
        }, this);
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    let t3;
    if ($[3] !== message) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "error-message",
            children: message
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 30,
            columnNumber: 10
        }, this);
        $[3] = message;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== onRetry) {
        t4 = onRetry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "retry-button",
            onClick: onRetry,
            children: "Try Again"
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 38,
            columnNumber: 21
        }, this);
        $[5] = onRetry;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== t3 || $[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "error-container",
            children: [
                t1,
                t2,
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ErrorMessage.jsx",
            lineNumber: 46,
            columnNumber: 10
        }, this);
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_c = ErrorMessage;
var _c;
__turbopack_context__.k.register(_c, "ErrorMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ARModelViewer.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ARModelViewer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ARModelViewer({ modelUrl, onClose, onError }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [modelLoaded, setModelLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const modelViewerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ARModelViewer.useEffect": ()=>{
            // Load model-viewer script if not already loaded
            if (!customElements.get("model-viewer")) {
                const script = document.createElement("script");
                script.type = "module";
                script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js";
                document.head.appendChild(script);
                script.onload = ({
                    "ARModelViewer.useEffect": ()=>{
                        console.log("[v0] Model viewer script loaded");
                    }
                })["ARModelViewer.useEffect"];
            }
            validateModelUrl(modelUrl);
        }
    }["ARModelViewer.useEffect"], [
        modelUrl
    ]);
    const validateModelUrl = (url)=>{
        // Basic URL validation
        try {
            const urlObj = new URL(url);
            const validExtensions = [
                ".glb",
                ".gltf"
            ];
            const hasValidExtension = validExtensions.some((ext)=>url.toLowerCase().includes(ext));
            if (!hasValidExtension) {
                setError("Invalid model format. Only GLB and GLTF models are supported.");
                setLoading(false);
                return;
            }
            // URL is valid, proceed to load
            setLoading(false);
        } catch (err) {
            console.error("[v0] Invalid URL:", err);
            setError("Invalid model URL. Please scan a valid QR code with a 3D model URL.");
            setLoading(false);
        }
    };
    const handleModelLoad = ()=>{
        console.log("[v0] Model loaded successfully");
        setModelLoaded(true);
        setError(null);
    };
    const handleModelError = (e)=>{
        console.error("[v0] Model loading error:", e);
        setError("Failed to load the 3D model. The URL may be invalid or the model file may be corrupted.");
        setLoading(false);
        if (onError) {
            onError("Failed to load model");
        }
    };
    const handleRetry = ()=>{
        setError(null);
        setLoading(true);
        setModelLoaded(false);
        // Force reload by updating key
        if (modelViewerRef.current) {
            modelViewerRef.current.src = "";
            setTimeout(()=>{
                modelViewerRef.current.src = modelUrl;
            }, 100);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "ar-model-viewer-overlay",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "ar-model-viewer-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "ar-viewer-header",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            children: "AR Model Preview"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ARModelViewer.jsx",
                            lineNumber: 75,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "ar-close-button",
                            onClick: onClose,
                            "aria-label": "Close Viewer",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "24",
                                height: "24",
                                viewBox: "0 0 24 24",
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M18 6L6 18M6 6l12 12"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 78,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                lineNumber: 77,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/ARModelViewer.jsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ARModelViewer.jsx",
                    lineNumber: 74,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "ar-viewer-content",
                    children: [
                        loading && !error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ar-loader",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "spinner"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 85,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Validating model URL..."
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 86,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/ARModelViewer.jsx",
                            lineNumber: 84,
                            columnNumber: 33
                        }, this),
                        error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ar-error-state",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "64",
                                    height: "64",
                                    viewBox: "0 0 24 24",
                                    fill: "none",
                                    stroke: "currentColor",
                                    strokeWidth: "2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "12",
                                            cy: "12",
                                            r: "10"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ARModelViewer.jsx",
                                            lineNumber: 91,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M15 9l-6 6m0-6l6 6"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ARModelViewer.jsx",
                                            lineNumber: 92,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 90,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "ar-error-message",
                                    children: error
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 94,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "ar-error-actions",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "ar-retry-button",
                                            onClick: handleRetry,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "20",
                                                    height: "20",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "currentColor",
                                                    strokeWidth: "2",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        d: "M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                                        lineNumber: 98,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                                    lineNumber: 97,
                                                    columnNumber: 19
                                                }, this),
                                                "Retry"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/ARModelViewer.jsx",
                                            lineNumber: 96,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "ar-back-button",
                                            onClick: onClose,
                                            children: "Back"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ARModelViewer.jsx",
                                            lineNumber: 102,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/ARModelViewer.jsx",
                            lineNumber: 89,
                            columnNumber: 20
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "ar-model-wrapper",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("model-viewer", {
                                        ref: modelViewerRef,
                                        src: modelUrl,
                                        ar: true,
                                        "ar-modes": "webxr scene-viewer quick-look",
                                        "camera-controls": true,
                                        "auto-rotate": true,
                                        "shadow-intensity": "1",
                                        style: {
                                            width: "100%",
                                            height: "500px"
                                        },
                                        onLoad: handleModelLoad,
                                        onError: handleModelError
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                        lineNumber: 108,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 107,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "ar-instructions",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "ar-info-card",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "24",
                                                height: "24",
                                                viewBox: "0 0 24 24",
                                                fill: "none",
                                                stroke: "currentColor",
                                                strokeWidth: "2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "2",
                                                        y: "3",
                                                        width: "20",
                                                        height: "14",
                                                        rx: "2",
                                                        ry: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                                        lineNumber: 117,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        d: "M8 21h8M12 17v4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                                        lineNumber: 118,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                                lineNumber: 116,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        children: "View in AR"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                                        lineNumber: 121,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "Click the AR button in the viewer to place this model in your real environment"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                                        lineNumber: 122,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/ARModelViewer.jsx",
                                                lineNumber: 120,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ARModelViewer.jsx",
                                        lineNumber: 115,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ARModelViewer.jsx",
                                    lineNumber: 114,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ARModelViewer.jsx",
                    lineNumber: 83,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ARModelViewer.jsx",
            lineNumber: 73,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/ARModelViewer.jsx",
        lineNumber: 72,
        columnNumber: 10
    }, this);
}
_s(ARModelViewer, "QEl2oDSSJNuP9rjhna41trVMyz8=");
_c = ARModelViewer;
var _c;
__turbopack_context__.k.register(_c, "ARModelViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/services/api.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// // Mock API service - Replace with your actual API endpoint
// const API_BASE_URL = "https://your-api-endpoint.com/api"
// const MODELS_PER_PAGE = 10
// const mockModels = [
//   {
//     modelName: "Vernier Caliper",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 2.5,
//     dracoSize: 1200,
//   },
//   {
//     modelName: "Spherometer",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 3.1,
//     dracoSize: 1500,
//   },
//   {
//     modelName: "Screw Gauge",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 2.8,
//     dracoSize: 1300,
//   },
//   {
//     modelName: "Microscope",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 4.2,
//     dracoSize: 2000,
//   },
//   {
//     modelName: "Laboratory Flask",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 1.8,
//     dracoSize: 900,
//   },
//   {
//     modelName: "Test Tube",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 1.5,
//     dracoSize: 800,
//   },
//   {
//     modelName: "Beaker",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 2.2,
//     dracoSize: 1100,
//   },
//   {
//     modelName: "Bunsen Burner",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 3.5,
//     dracoSize: 1700,
//   },
//   {
//     modelName: "Telescope",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 5.1,
//     dracoSize: 2500,
//   },
//   {
//     modelName: "Barometer",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 2.9,
//     dracoSize: 1400,
//   },
//   {
//     modelName: "Compass",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 1.6,
//     dracoSize: 850,
//   },
//   {
//     modelName: "Protractor",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 1.2,
//     dracoSize: 700,
//   },
//   {
//     modelName: "Thermometer",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 1.4,
//     dracoSize: 750,
//   },
//   {
//     modelName: "Multimeter",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 2.7,
//     dracoSize: 1350,
//   },
//   {
//     modelName: "Oscilloscope",
//     URL: "/assets/3d/duck.glb",
//     dracoURL: null,
//     posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
//     modelSize: 4.8,
//     dracoSize: 2300,
//   },
// ]
// export async function fetch3dModels(page = 1) {
//   try {
//     // Attempt to fetch from real API
//     const response = await fetch(`https://prod-api.melzoguru.in/fetchModel/chapter/467/10/0?page=${page}&limit=${MODELS_PER_PAGE}`)
//     if (!response.ok) {
//       throw new Error("API request failed")
//     }
//     const data = await response.json()
//     return {
//       models: data.models || [],
//       totalCount: data.totalCount || 0,
//       isAllModelsFetched: data.isAllModelsFetched || false,
//     }
//   } catch (error) {
//     console.warn("API fetch failed, using mock data:", error)
//     // Return mock data as fallback
//     const start = (page - 1) * MODELS_PER_PAGE
//     const end = start + MODELS_PER_PAGE
//     const paginatedModels = mockModels.slice(start, end)
//     // Simulate network delay
//     await new Promise((resolve) => setTimeout(resolve, 800))
//     return {
//       models: paginatedModels,
//       totalCount: mockModels.length,
//       isAllModelsFetched: end >= mockModels.length,
//     }
//   }
// }
// Mock API service - Replace with your actual API endpoint
__turbopack_context__.s([
    "fetch3dModels",
    ()=>fetch3dModels
]);
const API_BASE_URL = "https://your-api-endpoint.com/api";
const MODELS_PER_PAGE = 10;
const staticModelsWithAudio = [
    {
        modelName: "Astronaut",
        URL: "https://modelviewer.dev/shared-assets/models/Astronaut.glb",
        iosModelUrl: "https://modelviewer.dev/shared-assets/models/Astronaut.usdz",
        posterImage: "https://modelviewer.dev/shared-assets/models/Astronaut.webp",
        audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
        modelSize: 4.2,
        dracoSize: 2000,
        hasAR: true,
        hasAudio: true
    },
    {
        modelName: "RobotExpressive",
        URL: "https://modelviewer.dev/shared-assets/models/RobotExpressive.glb",
        iosModelUrl: null,
        posterImage: "https://modelviewer.dev/shared-assets/models/RobotExpressive.webp",
        audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
        modelSize: 5.1,
        dracoSize: 2500,
        hasAR: true,
        hasAudio: true
    },
    {
        modelName: "ShopifyShoe",
        URL: "https://modelviewer.dev/shared-assets/models/NeilArmstrong.glb",
        iosModelUrl: "https://modelviewer.dev/shared-assets/models/NeilArmstrong.usdz",
        posterImage: "https://modelviewer.dev/shared-assets/models/NeilArmstrong.webp",
        audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
        modelSize: 3.8,
        dracoSize: 1800,
        hasAR: true,
        hasAudio: true
    }
];
const mockModels = [
    {
        modelName: "Vernier Caliper",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 2.5,
        dracoSize: 1200
    },
    {
        modelName: "Spherometer",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 3.1,
        dracoSize: 1500
    },
    {
        modelName: "Screw Gauge",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 2.8,
        dracoSize: 1300
    },
    {
        modelName: "Microscope",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 4.2,
        dracoSize: 2000
    },
    {
        modelName: "Laboratory Flask",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 1.8,
        dracoSize: 900
    },
    {
        modelName: "Test Tube",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 1.5,
        dracoSize: 800
    },
    {
        modelName: "Beaker",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 2.2,
        dracoSize: 1100
    },
    {
        modelName: "Bunsen Burner",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 3.5,
        dracoSize: 1700
    },
    {
        modelName: "Telescope",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 5.1,
        dracoSize: 2500
    },
    {
        modelName: "Barometer",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 2.9,
        dracoSize: 1400
    },
    {
        modelName: "Compass",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 1.6,
        dracoSize: 850
    },
    {
        modelName: "Protractor",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 1.2,
        dracoSize: 700
    },
    {
        modelName: "Thermometer",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 1.4,
        dracoSize: 750
    },
    {
        modelName: "Multimeter",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 2.7,
        dracoSize: 1350
    },
    {
        modelName: "Oscilloscope",
        URL: "/assets/3d/duck.glb",
        dracoURL: null,
        posterImage: "https://melzo-guru.s3.ap-south-1.amazonaws.com/images/image/lesson-plan/3D+Model.jpg",
        modelSize: 4.8,
        dracoSize: 2300
    }
];
async function fetch3dModels(page = 1) {
    try {
        // Attempt to fetch from real API
        const response = await fetch(`${API_BASE_URL}/models?page=${page}&limit=${MODELS_PER_PAGE}`);
        if (!response.ok) {
            throw new Error("API request failed");
        }
        const data = await response.json();
        const allModels = page === 1 ? [
            ...staticModelsWithAudio,
            ...data.models || []
        ] : data.models || [];
        return {
            models: allModels,
            totalCount: (data.totalCount || 0) + (page === 1 ? staticModelsWithAudio.length : 0),
            isAllModelsFetched: data.isAllModelsFetched || false
        };
    } catch (error) {
        console.warn("API fetch failed, using mock data:", error);
        const allMockModels = page === 1 ? [
            ...staticModelsWithAudio,
            ...mockModels
        ] : mockModels;
        const start = page === 1 ? 0 : (page - 1) * MODELS_PER_PAGE;
        const end = start + MODELS_PER_PAGE;
        const paginatedModels = allMockModels.slice(start, end);
        // Simulate network delay
        await new Promise((resolve)=>setTimeout(resolve, 800));
        return {
            models: paginatedModels,
            totalCount: allMockModels.length,
            isAllModelsFetched: end >= allMockModels.length
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Header$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/Header.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelList$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ModelList.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ModelViewer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Loader$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/Loader.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ErrorMessage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ErrorMessage.jsx [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module './components/QRScanner'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ARModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ARModelViewer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/services/api.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function Page() {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pageFromUrl = Number.parseInt(searchParams.get("page")) || 1;
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [filteredModels, setFilteredModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedModel, setSelectedModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(pageFromUrl);
    const [totalPages, setTotalPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [showQRScanner, setShowQRScanner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showARViewer, setShowARViewer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [scannedModelUrl, setScannedModelUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            loadModels(pageFromUrl);
        }
    }["Page.useEffect"], [
        pageFromUrl
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            if (searchQuery.trim()) {
                const filtered = models.filter({
                    "Page.useEffect.filtered": (model)=>model.modelName.toLowerCase().includes(searchQuery.toLowerCase().trim())
                }["Page.useEffect.filtered"]);
                setFilteredModels(filtered);
            } else {
                setFilteredModels(models);
            }
        }
    }["Page.useEffect"], [
        searchQuery,
        models
    ]);
    const loadModels = async (page = 1)=>{
        try {
            setLoading(true);
            setError(null);
            const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetch3dModels"])(page);
            if (response.models && response.models.length > 0) {
                setModels(response.models);
                setFilteredModels(response.models);
                setCurrentPage(page);
                const itemsPerPage = 10;
                const totalItems = response.totalCount || response.models.length;
                setTotalPages(Math.ceil(totalItems / itemsPerPage));
            } else {
                setModels([]);
                setFilteredModels([]);
                setError("No models available at the moment.");
            }
            setLoading(false);
        } catch (err) {
            console.error("Error loading models:", err);
            setError("Failed to load 3D models. Please try again later.");
            setLoading(false);
        }
    };
    const handlePageChange = (newPage)=>{
        router.push(`?page=${newPage}`);
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    const handleModelSelect = (model_0)=>{
        setSelectedModel(model_0);
    };
    const handleBackToList = ()=>{
        setSelectedModel(null);
    };
    const handleQRScanClick = ()=>{
        setShowQRScanner(true);
    };
    const handleQRScanSuccess = (url)=>{
        setScannedModelUrl(url);
        setShowQRScanner(false);
        setShowARViewer(true);
    };
    const handleCloseQRScanner = ()=>{
        setShowQRScanner(false);
    };
    const handleCloseARViewer = ()=>{
        setShowARViewer(false);
        setScannedModelUrl(null);
    };
    const handleARViewerError = (error_0)=>{
        console.error("[v0] AR Viewer error:", error_0);
    };
    const handleSearch = (query)=>{
        setSearchQuery(query);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "app",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Header$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onQRScanClick: handleQRScanClick,
                onSearch: handleSearch,
                searchQuery: searchQuery
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "main-content",
                children: loading && models.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$Loader$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    message: "Loading 3D Models..."
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 102,
                    columnNumber: 43
                }, this) : error && models.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ErrorMessage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    message: error,
                    onRetry: ()=>loadModels(currentPage)
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 102,
                    columnNumber: 118
                }, this) : selectedModel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    model: selectedModel,
                    onBack: handleBackToList,
                    allModels: filteredModels,
                    onSelectModel: handleModelSelect
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 102,
                    columnNumber: 209
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ModelList$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    models: filteredModels,
                    onSelectModel: handleModelSelect,
                    currentPage: currentPage,
                    totalPages: totalPages,
                    onPageChange: handlePageChange,
                    loading: loading,
                    searchQuery: searchQuery
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 102,
                    columnNumber: 336
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            showQRScanner && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QRScanner, {
                onScanSuccess: handleQRScanSuccess,
                onClose: handleCloseQRScanner
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 105,
                columnNumber: 25
            }, this),
            showARViewer && scannedModelUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ARModelViewer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                modelUrl: scannedModelUrl,
                onClose: handleCloseARViewer,
                onError: handleARViewerError
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 107,
                columnNumber: 43
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.js",
        lineNumber: 98,
        columnNumber: 10
    }, this);
}
_s(Page, "nyoaUy5Wmv4twNkUzTxbOWmSfv0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = Page;
var _c;
__turbopack_context__.k.register(_c, "Page");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_8ed6d1b9._.js.map